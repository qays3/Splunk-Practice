



## Table of Contents

1. [Chapter 1: Architecture and Core Components]
2. [Chapter 2: Installation, Hardening, and Startup]
3. [Chapter 3: Configuration Files and Layering]
4. [Chapter 4: Indexes, Buckets, and Data Lifecycle]
5. [Chapter 5: Data Ingestion Methods]
6. [Chapter 6: Deployment Server]
7. [Chapter 7: Splunk Processing Language (SPL)]
8. [Chapter 8: Apps, Add-ons, and User Management]
9. [Chapter 9: Authentication and Multi-Factor]
10. [Chapter 10: Distributed Search]
11. [Chapter 11: Licensing]
12. [Chapter 12: Monitoring Console and Forwarder Health]
13. [Chapter 13: Sysmon and Windows Log Collection]
14. [Chapter 14: Detection Use Cases]
15. [Chapter 15: Health Monitoring and Operational Practices]
16. [Chapter 16: Detection Engineering Framework]
17. [Appendix: Quick Reference]

---

## Chapter 1: Architecture and Core Components

Before deploying Splunk in any environment, you need a precise mental model of its components and how they relate to each other. Every administration decision - from hardware sizing to firewall rules - flows from this understanding.

### 1.1 The Three-Tier Architecture

Splunk separates its functionality into three logical tiers:

- **Data collection** - Forwarders
- **Data storage and indexing** - Indexers (also called Search Peers in distributed environments)
- **Data search and visualization** - Search Heads

In a small lab, all three tiers can run on a single machine. In production they run on separate servers - sometimes dozens - to handle scale and provide redundancy.

```
┌─────────────────────────────────────────────────────────────────────┐
│                  SPLUNK THREE-TIER ARCHITECTURE                     │
│                                                                     │
│  TIER 1: COLLECTION        TIER 2: STORAGE         TIER 3: SEARCH   │
│                                                                     │
│  [Endpoints]               [Indexers]              [Search Heads]   │
│  UF --> UF --> UF  ──────> IDX  IDX  IDX  <──────  SH   SH          │
│  HF                        IDX  IDX  IDX           SH               │
│  HEC / Syslog                                                       │
└─────────────────────────────────────────────────────────────────────┘
```

The Search Head is the component that **consolidates individual results and prepares reports** in a distributed environment. It distributes search queries to all relevant indexers (search peers), which run searches **in parallel** and return their portions of results. The search head then merges and presents the final result.

---

### 1.2 The Indexer

The Indexer is the persistence and processing engine. When raw log data arrives, the Indexer performs the following steps in order:

**1. Line breaking** - splits the incoming data stream into individual events using rules defined in `props.conf`.

**2. Timestamp extraction** - locates the time value inside each event and converts it to UNIX epoch for consistent searching across all time zones.

**3. Field parsing** - identifies key=value pairs and structured formats (JSON, CSV, XML) and extracts them as indexed fields.

**4. Writing to disk** - stores compressed raw event data alongside a `.tsidx` inverted-index file. The `.tsidx` file maps search terms to the exact file offset where the raw event lives.

**Why this matters:** the Indexer does the hard parsing work exactly once, at ingest time. When you run a search later, Splunk does not scan raw text - it looks up terms in the `.tsidx` and jumps directly to matching events. This is why searches over billions of events complete in seconds.

The Indexer is also referred to as a **Search Peer** when viewed from the Search Head's perspective. The search peer performs indexing and responds to search requests from the search head.

**License metering occurs during the Indexing phase.** Every event written to a non-internal index is measured at this point. If you exceed the daily limit, indexing continues but search is affected after license violation thresholds are crossed.

---

### 1.3 The Forwarder

A Forwarder is a lightweight Splunk agent installed on endpoints to collect and transmit log data to the Indexer. There are two types.

#### Universal Forwarder (UF)

The Universal Forwarder is a stripped-down Splunk binary with one job: read files and stream raw bytes to an Indexer over TCP port 9997. It does not parse, normalize, or index data. It uses under 100 MB RAM at rest and has negligible CPU impact. Because of this, the UF can be installed on every server in an organization without meaningful performance degradation.

The UF is the correct choice for endpoint log collection in nearly all deployments. **It comes with a built-in license** - a forwarder-specific license that allows forwarding without consuming an Enterprise license. Universal Forwarders require a **separate installation package** from Splunk Enterprise.

Key capabilities of the Universal Forwarder:

- **Compressing data** before sending it to the indexer (using zlib by default)
- **Indexer acknowledgement** - ensures data is confirmed received before deleting local copy

The UF does NOT:

- Send alerts
- Obfuscate or hide data
- Parse or index data
- Apply props.conf event-breaking rules

`props.conf` is a Splunk configuration file that controls how Splunk **parses and processes incoming data** at index time and search time.

#### Heavy Forwarder (HF)

The Heavy Forwarder is a full Splunk Enterprise installation running in forwarding mode. Because it contains the full Splunk pipeline, it can parse, filter, mask, and route data before forwarding it. This is useful when:

- You need to mask sensitive data (PII, credentials) before it reaches the Indexer
- You are aggregating logs from many sources through one intermediate hop
- You need to route different events to different Indexers based on content
- You need to perform line breaking prior to indexing

The Heavy Forwarder **requires a Forwarder license** because it performs parsing and indexing operations. It is the only forwarder type that can parse data prior to forwarding. For syslog files being monitored on a Heavy Forwarder, the TRANSFORMS configuration should be deployed directly on the Heavy Forwarder, not on the indexer.

|Feature|Heavy Forwarder|Universal Forwarder|
|---|---|---|
|Collects log files|Yes|Yes|
|Forwards to Indexer|Yes|Yes|
|Parses and transforms data|Full parsing pipeline|Minimal - raw data only|
|Applies routing and filtering|Yes|Limited|
|Resource footprint|High - full Splunk instance|Very low - stripped binary|
|Requires Splunk license|Yes (Forwarder license)|No (built-in license)|
|Typical use|Intermediate aggregation node|Every endpoint to be monitored|
|Performs line breaking|Yes|No|

**Recommended forwarder for production:** Universal Forwarder. The Heavy Forwarder is used only when pre-indexing processing is required.

**Pre-indexing processing** means transforming, filtering, or modifying the raw data **before it gets written to the index** on the Indexer.

---

### 1.4 The Search Head

The Search Head provides the web interface where analysts write and run queries. When you execute a search, the following happens:

1. The Search Head compiles your SPL query into an internal execution plan.
2. It distributes the search to all relevant Indexers simultaneously.
3. Each Indexer searches its own data independently and returns matching events.
4. The Search Head merges, sorts, deduplicates, and presents the final result.

In a distributed environment with multiple Indexers, all of them work in parallel. This is how Splunk scales to terabytes - no single machine needs to hold all the data, and searches fan out across all Indexers at once.

**All search-time field extractions should be specified on the Search Head.** This centralizes search processing logic, allows user-specific customization, and avoids reindexing data when extraction rules change.

To **increase the number of simultaneous searches** on a single search head, the hardware attribute to change is **CPUs**. Each search requires CPU cycles; adding cores allows more searches to run concurrently.

For **real-time searches**, results are pulled from the **Search Peers** (indexers), where the indexed data resides.

When an indexer crashes mid-search in a non-clustered environment, Splunk **informs the user in Splunk Web that their results may be incomplete.** It does not automatically retry on another indexer.

---

### 1.5 Additional Roles in Enterprise Deployments

#### Deployment Server

Centralizes configuration management for Forwarders. Instead of logging into hundreds of endpoints to push a configuration change, you stage the change on the Deployment Server. Each Forwarder polls the Deployment Server every 60 seconds (configurable) and pulls any updated configuration packages.

The Deployment Server:

- Requires an **Enterprise license**
- Is responsible for **sending apps to forwarders**
- Does NOT automatically restart the host OS running the forwarder
- Can manage forwarders using `serverclass.conf`
- Apps must be in `$SPLUNK_HOME/etc/deployment-apps` on the Deployment Server
- In a **non-cluster environment**, can **automatically restart** remote Splunk instances after configuration changes

#### Deployer

Manages Search Head clusters specifically. The Deployer distributes apps and certain other configuration updates to **search head cluster members**. It is a distinct role from the Deployment Server. The Deployer does not serve forwarders.

#### Cluster Manager (formerly Master Node)

In a clustered Indexer environment, the Cluster Manager coordinates data replication across multiple Indexers. If one Indexer goes offline, the Cluster Manager ensures its data exists on other Indexers and that searches still return complete results.

#### License Manager (License Master)

One Splunk instance acts as the central license authority. All other instances report their daily indexed data volume to it. License files are stored at `$SPLUNK_HOME/etc/licenses`.

#### Monitoring Console

A built-in set of dashboards that provides health metrics across the entire Splunk deployment. The Monitoring Console monitors forwarders by receiving **internal logs forwarded by forwarders** - it does not pull logs directly from forwarders. To remove missing forwarders from the Monitoring Console, **rebuild the forwarder asset table**.

---

### 1.6 Deployment Topologies

**Standalone** - all components on a single machine. Appropriate for labs and small deployments under a few GB/day. No redundancy.

**Basic with Forwarders** - a central Splunk Enterprise instance handles indexing and searching, with Universal Forwarders on endpoints. The most common small-to-medium deployment pattern.

**Distributed / Clustered** - multiple Indexers in an indexing cluster, multiple Search Heads in a Search Head cluster, a Cluster Manager, a Deployer, and a Deployment Server for Forwarders.

**Required components for 50 Linux + 200 Windows servers:** Indexers, Search Head, Deployment Server, License Master, Universal Forwarders.

**Required for a Search Head Cluster:** a Deployer as the additional mandatory component.

---

## Chapter 2: Installation, Hardening, and Startup

### 2.1 Pre-Installation: Why /opt and Why a Dedicated User

Splunk's official guidance is to install under `/opt`. Creating a dedicated system user named `splunk` and assigning it ownership of `/opt/splunk` is a security requirement. Splunk's process runs as this unprivileged user, not as root.

---

### 2.2 Installation Steps on Ubuntu Server

```bash
apt update && apt upgrade -y
useradd -m -r splunk
wget -O splunk.tgz 'https://download.splunk.com/products/splunk/releases/9.2.1/linux/splunk-9.2.1-<BUILD>-Linux-x86_64.tgz'
tar -xvzf splunk.tgz -C /opt
chown -R splunk:splunk /opt/splunk
/opt/splunk/bin/splunk start --accept-license
/opt/splunk/bin/splunk enable boot-start -user splunk
sudo ufw allow 8000/tcp    # Web UI
sudo ufw allow 9997/tcp    # Forwarder data
sudo ufw reload
```

**Default ports:**

- Web UI: `8000`
- Forwarder-to-Indexer data: `9997`
- Management API: `8089`
- HTTP Event Collector (HEC): `8088`

---

### 2.3 Disabling Transparent Huge Pages (THP)

Splunk's official documentation requires THP to be disabled for production deployments. Splunk's memory access pattern is fragmented (many small, simultaneous I/O operations) and THP's background compaction process directly competes with Splunk's I/O.

---

### 2.4 Increasing ulimits

Fix in `/etc/security/limits.conf`:

```
*   soft   nofile      65536
*   hard   nofile      65536
*   hard   nproc       unlimited
*   soft   nproc       unlimited
```

---

### 2.5 Essential CLI Commands

```bash
./splunk start
./splunk stop
./splunk restart
./splunk status
./splunk btool <conf_name> list <stanza> --debug
./splunk add oneshot <filepath> -index <indexname>
./splunk clean eventdata -index <indexname> -f
./splunk enable listen 9997
./splunk add forward-server <INDEXER_IP>:9997
./splunk set deploy-poll <DEPLOYMENT_SERVER_IP>:8089
./splunk list forward-server
./splunk check-integrity -index <index_name> [-verbose]
```

**`btool` behavior:** `btool` reads configuration files **directly from disk**. If you update a config file while Splunk is running and run `btool --debug` without restarting, it will show the **on-disk** configuration (with your changes) along with the file path. It does NOT show the currently running configuration.

**`splunk check-integrity`:** Used to verify the integrity of a **local index's on-disk artifacts**. Not applicable to SmartStore indexes.

**`splunk add oneshot`:** Ingests a file a single time without creating a persistent monitor. Does not write to the fishbucket, so future updates to the file are not tracked. Correct for one-time incident evidence ingestion.

**`splunk cmd btprobe`:** Used to reset fishbucket entries for a specific file:

```bash
./splunk cmd btprobe -d $SPLUNK_HOME/var/lib/splunk/fishbucket/splunk_private_db --file /path/to/file --reset
```

**Configuring a deployment client:** `splunk set deploy-poll deployServer:port` - this creates `deploymentserver.conf` in `$SPLUNK_HOME/etc/system/local`.

**Viewing forwarder-to-indexer configuration:** `splunk list forward-server`

---

## Chapter 3: Configuration Files and Layering

Splunk's behavior is controlled entirely through plaintext `.conf` files. Understanding how these files are structured, where they live, and how they are merged at runtime is essential for any administrator.

### 3.1 The Directory Structure

```
/opt/splunk/
├── bin/
├── etc/
│   ├── apps/                  
│   ├── deployment-apps/         
│   ├── master-apps/            
│   ├── shcluster/               
│   ├── licenses/               
│   └── system/
│       ├── default/             
│       └── local/               
└── var/
    ├── log/splunk/
    └── lib/splunk/              
```

The **parent directory for all configuration files** is `$SPLUNK_HOME/etc`.

`$SPLUNK_HOME/etc/system/default` - Splunk factory defaults, never modify. `$SPLUNK_HOME/etc/system/local` - where the `deploymentserver.conf` is created by `splunk set deploy-poll`. `$SPLUNK_HOME/etc/deployment-apps` - where apps are placed on the Deployment Server for client distribution. `$SPLUNK_HOME/etc/apps` - where installed apps live on a Splunk instance; where Deployment Server apps land on clients after deployment. `$SPLUNK_HOME/etc/licenses` - where license files are stored.

---

### 3.2 The Most Important Configuration Files

| File                    | Purpose                                                                                                                                    |
| ----------------------- | ------------------------------------------------------------------------------------------------------------------------------------------ |
| `inputs.conf`           | Defines what data sources Splunk monitors - file paths, syslog ports, Windows Event Logs, HEC tokens, scripted inputs                      |
| `outputs.conf`          | Defines where a Forwarder sends its data - the Indexer IP and receiving port. Used to forward internal logs from search heads to indexers. |
| `props.conf`            | Controls data parsing: timestamp extraction, line breaking rules, SEDCMD for data masking, character encoding, TRANSFORMS references       |
| `transforms.conf`       | Works with props.conf for field extractions, data masking (REGEX + DEST_KEY + FORMAT), and data routing logic                              |
| `indexes.conf`          | Defines indexes - their disk paths, retention periods, size limits, and bucket settings. Also used to enable data integrity checking.      |
| `server.conf`           | Core server identity - server name, license configuration, clustering, SSL                                                                 |
| `deploymentclient.conf` | Configures a Forwarder to register with and poll a Deployment Server                                                                       |
| `serverclass.conf`      | Maps deployment apps to deployment clients on the Deployment Server                                                                        |
| `distsearch.conf`       | Configures distributed search groups and search peer registration                                                                          |
| `authentication.conf`   | Configures authentication methods including LDAP, SAML, Duo MFA                                                                            |
| `authorize.conf`        | Defines role-based access control and capabilities                                                                                         |
| `wmi.conf`              | Configures remote Windows Management Instrumentation inputs                                                                                |
| `web.conf`              | Web interface settings                                                                                                                     |

### 1. `inputs.conf`

_Tells Splunk **what data to collect**_

```ini
# /opt/splunk/etc/system/local/inputs.conf

[monitor:///var/log/syslog]
disabled = false
index = linux_logs
sourcetype = syslog

[monitor:///var/log/apache2/access.log]
disabled = false
index = web_logs
sourcetype = access_combined

[udp://514]
connection_host = ip
index = network_logs
sourcetype = syslog
```

---

### 2. `outputs.conf`

_Tells Splunk **where to send data** (forwarder → indexer)_

```ini
# /opt/splunk/etc/system/local/outputs.conf

[tcpout]
defaultGroup = my_indexers

[tcpout:my_indexers]
server = 192.168.1.10:9997, 192.168.1.11:9997
compressed = true
```

---

### 3. `indexes.conf`

_Defines **index storage locations and retention**_

```ini
# /opt/splunk/etc/system/local/indexes.conf

[linux_logs]
homePath   = $SPLUNK_DB/linux_logs/db
coldPath   = $SPLUNK_DB/linux_logs/colddb
thawedPath = $SPLUNK_DB/linux_logs/thaweddb
maxTotalDataSizeMB = 50000
frozenTimePeriodInSecs = 2592000
```

---

### 4. `transforms.conf`

_Defines **field extractions, lookups, and routing rules**_

```ini
# /opt/splunk/etc/system/local/transforms.conf

[extract_src_ip]
REGEX = src_ip=(\d+\.\d+\.\d+\.\d+)
FORMAT = src_ip::$1

[firewall_lookup]
filename = firewall_zones.csv
```

---

### 5. `props.conf`

_Defines **how data is parsed** — sourcetype behavior_

```ini
# /opt/splunk/etc/system/local/props.conf

[access_combined]
TIME_FORMAT = %d/%b/%Y:%H:%M:%S %z
TRANSFORMS-extract = extract_src_ip
MAX_TIMESTAMP_LOOKAHEAD = 40
LINE_BREAKER = ([\r\n]+)
```

---

### 6. `server.conf`

_Core **Splunk server settings** — clustering, SSL, limits_

```ini
# /opt/splunk/etc/system/local/server.conf

[general]
serverName = splunk-indexer-01
pass4SymmKey = my_secret_key

[clustering]
mode = peer
master_uri = https://192.168.1.5:8089
pass4SymmKey = cluster_secret

[diskUsage]
minFreeSpace = 2000
```

---

### 7. `authentication.conf`

_Defines **how users log in** (LDAP, SAML, etc.)_

```ini
# /opt/splunk/etc/system/local/authentication.conf

[authentication]
authType = LDAP
authSettings = my_ldap

[my_ldap]
host = ldap.company.com
SSLEnabled = 1
bindDN = cn=splunk,dc=company,dc=com
bindDNpassword = secret
userBaseDN = ou=users,dc=company,dc=com
groupBaseDN = ou=groups,dc=company,dc=com
```

---

### How They Relate to Each Other

```
inputs.conf       →  collects data
     ↓
props.conf        →  parses/formats it
transforms.conf   →  extracts fields / routes it
     ↓
indexes.conf      →  stores it
     ↓
outputs.conf      →  forwards it (on forwarders)
```

Each file lives in one of these layers, with the `local/` directory always winning over `default/`:

```
$SPLUNK_HOME/etc/system/default/   ← Splunk's shipped defaults
$SPLUNK_HOME/etc/system/local/     ← Your overrides (never edit default/)
$SPLUNK_HOME/etc/apps/<appname>/   ← App-specific configs
```


**Configuration files for transforming raw data:** `props.conf` and `transforms.conf`.

**SEDCMD** is used in `props.conf` to modify raw data at index time. It applies sed-like substitutions on the raw event text before indexing. Example for masking a password:

```ini
[identity]
SEDCMD-redact_pw = s/password=([^,|\s]+)/####REDACTED####/g
```

**Configuration files used with a Universal Forwarder:** `inputs.conf` and `outputs.conf`. There is no standard `monitor.conf` or `forwarder.conf`.

---

### 3.3 Configuration File Format

```ini
[stanza_name]
key = value
another_key = another_value

[another_stanza]
key = value
```

**Valid stanza types in props.conf for data modification:** Host (`[host::<hostname>]`), Source (`[source::<source_path>]`), and Sourcetype (`[sourcetype::<sourcetype_name>]`). There is no `[server::]` stanza for data modification.

**CHARSET** is properly configured at the source level:

```ini
[source::/var/log/splunk]
CHARSET = BIG5
```

**If a sourcetype is explicitly set in inputs.conf**, it cannot be changed via props.conf during the Input phase. The inputs.conf assignment takes precedence.

---

### 3.4 Configuration Layering - Why It Exists and How It Works

The priority of layered Splunk configuration files depends on the file's **Context**. Three contexts exist: App context, User context, and Global context. There is no Forwarder context in the standard layering model.

#### Global (Index Time) Precedence - lowest to highest

1. `system/default` - Splunk factory defaults. Never modify.
2. `apps/<appname>/default` - App-shipped defaults.
3. `apps/<appname>/local` - Your customizations within the app.
4. `system/local` - Overrides everything. Highest precedence.

**Index-time global context order (highest to lowest):**

1. `system/local`
2. App `local` directories
3. App `default` directories
4. `system/default`

The **users directory is never used** in the global/index-time context.

#### Search Time Precedence (during search, highest to lowest)

1. `users/<username>/<app>/local` - user context overrides
2. `apps/<appname>/local` - app local
3. `apps/<appname>/default` - app default
4. `system/local`
5. `system/default`

At search time, `$SPLUNK_HOME/etc/apps/app1/local` has the **highest precedence** among the listed directories (higher than system/local, higher than users/admin/local for the app's scope).

#### In an Indexer Cluster

When using an indexer cluster, the **app local directories move to second in the priority list**. Configurations pushed through the deployer via `master-apps` take higher precedence than local app directories directly placed on indexers.

#### Deployment Server Precedence

When a Deployment Server deploys an app with an `inputs.conf` in `local/`, it **overwrites** the local inputs.conf on the forwarder. The deployed configuration takes precedence. If a forwarder was manually configured for `/var/log/messages` and the Deployment Server deploys a new `my_TA` app with `/var/log/maillog`, only `/var/log/maillog` will be monitored.

**Clearing a setting in props.conf:** Change its value to null (empty string). This disables inherited settings such as field aliases.

---

### 3.5 Using btool to Inspect Effective Configuration

```bash
/opt/splunk/bin/splunk btool inputs list --debug
/opt/splunk/bin/splunk btool props list --debug
/opt/splunk/bin/splunk btool server list deployment_server --debug
/opt/splunk/bin/splunk btool inputs list http --debug
```

The `--debug` flag prints the source file path next to each setting. `btool` reads from disk - if Splunk has not been restarted since a file change, the running config may differ from what `btool` shows.

---

## Chapter 4: Indexes, Buckets, and Data Lifecycle

### 4.1 What an Index Actually Is on Disk

An index is a directory structure containing:

- **Compressed raw data** - the original event text.
- **`.tsidx` files** - Time-Series Index files for fast searching.
- **Buckets** - directories grouping raw data and `.tsidx` files by time range.

Buckets are the **objects that store events inside of an index**. Each bucket covers a specific time range and progresses through lifecycle stages (hot, warm, cold, frozen).

Default bucket storage directories:

- `db` - contains both hot and warm buckets
- `colddb` - contains cold buckets

---

### 4.2 The Bucket Lifecycle: Hot => Warm => Cold => Frozen => Thawed

|State|Read/Write|Default Location|What triggers the transition|
|---|---|---|---|
|**HOT**|Read + Write|`homePath` (`/db`)|Bucket reaches max size, max age, or max hot bucket count|
|**WARM**|Read only|`homePath` (`/db`)|Max warm bucket count (`maxWarmDBCount`) is reached|
|**COLD**|Read only|`coldPath` (`/colddb`)|Max warm bucket count is reached - oldest warm rolls to cold|
|**FROZEN**|Not searchable|`frozenPath` or deleted|Retention period expires|
|**THAWED**|Read only|`thawedPath`|Administrator manually restores frozen data|

**Warm bucket rolls to cold when:** the maximum number of warm buckets (`maxWarmDBCount`) is reached. This is the primary trigger, not size or age alone.

**Searchable bucket types:** Hot, Warm, and Cold. Frozen buckets are not directly searchable.

**Data integrity check** is enabled in `indexes.conf` and verifies that **raw data in the index** has not been tampered with - used for auditing and legal purposes.

**What data integrity check applies to:** only the raw data in the index (not lookup tables, summary indexes, or data model acceleration).

---

### 4.3 Built-in Splunk Indexes

| Index            | Purpose                                                              |
| ---------------- | -------------------------------------------------------------------- |
| `_internal`      | Splunk daemon logs - errors, performance metrics, pipeline activity. |
| `_audit`         | Audit trail - user logins, searches executed, configuration changes. |
| `_introspection` | System performance data.                                             |
| `_thefishbucket` | Checkpoint database for all monitored files.                         |
| `main`           | Default destination for data that does not specify an index.         |

**Pre-configured indexes that come with Splunk Enterprise:** `_internal` and `_thefishbucket`. `_licence` and `_external` are not pre-configured.

**To verify a successful Universal Forwarder connection via Splunk Web:** check `index=_internal` for connection status events.

---

### 4.4 The Fishbucket - Preventing Duplicate Ingestion

The fishbucket (`_thefishbucket`) tracks what has been indexed per file. If data was incorrectly indexed and needs to be reindexed:

1. Clean the target index (`splunk clean eventdata -index <indexname>`)
2. Also clean `_thefishbucket` to reset checkpoint information

**The fishbucket must be reset on the Forwarder, not the Indexer.** If an attribute in `inputs.conf` is updated on a Universal Forwarder, the fishbucket on the **forwarder** needs to be reset to force re-ingestion with the new configuration.

**A monitored log file is re-ingested by Splunk when the fish bucket checkpoint is cleared.**

Resetting the fishbucket for one source:

```bash
./splunk cmd btprobe -d $SPLUNK_HOME/var/lib/splunk/fishbucket/splunk_private_db --file /path/to/file --reset
```

---

### 4.5 Creating an Index via indexes.conf

Required settings when defining an index in `indexes.conf`:

- `homePath` - required
- `coldPath` - required
- `thawedPath` - required
- `frozenPath` - NOT strictly required (data is deleted if not set)

```ini
[security]
homePath = $SPLUNK_DB/security/db
homePath.maxDataSizeMB = 300000
coldPath = $SPLUNK_DB/security/colddb
coldToFrozenDir = $SPLUNK_DB/security/archive-security
thawedPath = $SPLUNK_DB/security/thaweddb
maxTotalDataSizeMB = 512000
maxDataSize = 20
maxHotBuckets = 5
frozenTimePeriodInSecs = 18835200
enableDataIntegrityControl = 1
compressRawdata = 1
```

**`frozenTimePeriodInSecs`** - controls the time period in seconds after which data moves through the hot/warm/cold lifecycle and is eventually frozen. This is the correct setting in `indexes.conf` that allows data retention to be controlled by time.

**`coldPath`** - used to direct older, less frequently accessed data to slower NAS storage. This is the parameter modified to implement a tiered storage retention strategy.

**Data integrity check** is configured via `indexes.conf` using `enableDataIntegrityControl = 1`.

**Reasons to create separate indexes:**

- Different retention times (the primary reason)
- Restrict user permissions (role-based index access)
- File organization is not a primary reason; increasing users is not a reason.

---

### 4.6 Data Ingestion Phases

The Splunk data pipeline has four phases:

1. **Input phase** - data is treated as streams. Character encoding is handled here. The data is a continuous flow, not yet broken into events. Indexed extractions in `props.conf` that apply at input time run here.
2. **Parsing phase** - data is broken into events with timestamps. This is the **last opportunity to define event boundaries.** Event-level transformations and line merging rules are applied. Event processing occurs during this phase.
3. **Indexing phase** - license metering occurs here. Data is written to disk, tsidx files are created.
4. **Search phase** - users query indexed data. Search-time field extractions run here.

**Indexed extractions in props.conf** (TRANSFORMS used at index time) occur during the **Parsing phase** when applied via `props.conf`. The Inputs phase handles initial stream receipt and character encoding.

**Which phase is the last opportunity for defining event boundaries:** Parsing phase.

---

## Chapter 5: Data Ingestion Methods

### 5.1 The Four Ingestion Methods

1. **File and directory monitoring** - Splunk tails log files directly on the host.
2. **Syslog (TCP/UDP)** - Network devices and servers push logs using the syslog protocol.
3. **Windows Event Log** - The Universal Forwarder reads from the Windows Event Log API.
4. **HTTP Event Collector (HEC)** - Applications send events directly over HTTP/HTTPS using a token.

**Adding inputs on a forwarder - supported methods:**

- CLI (`splunk add monitor`, etc.)
- Edit `inputs.conf` directly
- Forwarder Management (Deployment Server / GUI)
- Splunk Web

**Adding inputs in Splunk - supported methods:**

- CLI
- Splunk Web (GUI)
- Editing `inputs.conf` (though Splunk Web and CLI are preferred as they validate syntax)

`monitor.conf` is not a standard Splunk configuration file for input configuration.

**Available input methods when adding a file input in Splunk Web:**

- Index once (one-time batch ingestion)
- Continuously monitor (ongoing monitoring with file tracking)

---

### 5.2 Minimum Required Settings for Network Inputs

**Minimum required settings for a network input:**

- Protocol (TCP or UDP)
- Port number

Username/password, IP address, and location are not minimum requirements.

**Valid network input stanza example:**

```ini
[tcp://172.16.10.1:10001]
connection_host = dns
sourcetype = dns
```

**`connection_host`** attribute controls how Splunk handles the hostname/IP of the connecting client. Valid values: `ip`, `dns`, `none`. The `connection` attribute is not valid.

**Optional network input configuration options:**

- Metadata override
- Sender filtering options
- Network input queues (memory/persistent queues - not "quantum queues")

**Persistent queue for network inputs** (`persistentQueueSize`) - provides durable file-system buffering to mitigate data loss during network outages and splunkd restarts.

---

### 5.3 File Monitoring: Wildcards, Directories, and Special Parameters

|Pattern|Behavior|
|---|---|
|`*`|Matches any filename within a **single** directory level. Does not recurse.|
|`...`|Recursive - matches all files in a directory and all subdirectories at any depth.|

**Match all of these files:**

- `/var/log/www1/secure.log`
- `/var/log/www/secure.l`
- `/var/log/www/logs/secure.logs`
- `/var/log/www2/secure.log`

Correct stanza: `[monitor:///var/log/.../secure.*]` - the `...` handles any depth including zero, and `*` matches any extension.

`[monitor:///var/log/www*/secure.*]` would NOT match `/var/log/www/logs/secure.logs` because `*` does not cross directory boundaries.

**Monitor stanza: `[monitor:///var/log/*/bar/.../*.txt]`** - matches `/var/log/host_xxx/bar/foo.txt` (wildcard matches one directory level, `...` matches zero subdirectory levels). Does NOT match paths with directories before `bar/`.

**Directory inputs:**

- All discovered text files are consumed by default
- Splunk recursively traverses through the directory structure
- Compressed files are NOT ignored by default (Splunk can handle compressed files)
- New files added to a monitored directory are detected automatically - no forwarder restart required

**`ignoreOlderThan`** - valid option for `[monitor]` stanza. Instructs Splunk to only index events newer than the specified duration. Example: `ignoreOlderThan = 45d` collects data 45 days old and newer.

**`followTail`** - monitors a file for updates without indexing pre-existing data. Starts reading from the end of the file.

**`interval = 0`** for scripted inputs - causes the script to be restarted immediately upon exit, creating continuous execution.

**Whitelist/Blacklist filtering for monitor inputs** uses **regular expressions**. Wildcards-only and slash notation are not supported.

**Whitelists and blacklists in deployment server client filters:** the **blacklist takes precedence** over the whitelist.

---

### 5.4 Scripted Inputs

Scripts for scripted inputs can reside at:

- `$SPLUNK_HOME/bin/scripts`
- `$SPLUNK_HOME/etc/system/bin`
- `$SPLUNK_HOME/etc/apps/<your_app>/bin` (preferred)

`$SPLUNK_HOME/etc/apps/bin` (without a specific app name) is NOT a valid location.

---

### 5.5 HTTP Event Collector (HEC)

HEC is a **token-based HTTP input that is secure and scalable and does not require the use of forwarders.** It is not agent-based.

**HEC endpoint URI:** `services/collector` (for Splunk Enterprise customer-managed). Full path: `https://<host>:8088/services/collector/event`.

**Required in the HEC request header:** The **Token** (Authorization: Splunk ). ackID, manifest, and hostname are not required in the header.

**Sending multiple events through HEC:** Send multiple JSON objects back-to-back in the request body (each on its own line as newline-delimited JSON).

**HEC Indexer Acknowledgement:**

- Requires a **separate channel provided by the client** (the channel GUID)
- Provides end-to-end delivery confirmation
- The acceptable channel value is a **GUID** (Globally Unique Identifier), not an IP address, hash checksum, or DNS name
- Enabling indexer acknowledgement ensures events are confirmed indexed before the client removes its local copy
- Configuration is performed at the HEC token level, not globally

**Enabling indexer acknowledgment for HEC:** Select "Enable indexer acknowledgment" when creating/editing the HEC token.

---

### 5.6 Metadata Fields - Set at Ingest, Cannot Be Changed

Default metadata fields assigned at indexing time: `sourcetype`, `source`, `host`. The **index** is also metadata but is set in `inputs.conf`. The `_raw` field is the raw event data, not a metadata field. **Permissions** are NOT a default metadata value assigned at indexing.

**`_TCP_ROUTING`** - optional configuration setting in `inputs.conf` that allows selective forwarding of data to specific indexers based on routing rules.

**Windows Remote Inputs using WMI:** Defined in `wmi.conf`, not `inputs.conf`. Allows collecting Windows performance data from remote hosts **without installing Splunk software** on those clients.

**Default character encoding:** UTF-8. Splunk expects incoming data to be UTF-8 by default. Override with `CHARSET` in `props.conf`.

---

### 5.7 Load Balancing on Universal Forwarders

Automatic load balancing distributes data across multiple indexers using a round-robin algorithm. Configuration:

```ini
[tcpout:my_splunk_indexers]
server = indexer1:9997, indexer2:9997, indexer3:9997
```

**`autoLBFrequency`** - controls how often the forwarder checks and switches between indexers when automatic load balancing is enabled. This is the attribute to update to change the switching interval.

**`forceTimebasedAutoLB`** - if a Universal Forwarder is monitoring a very active syslog stream and is unable to switch between destinations, configure `forceTimebasedAutoLB` to force time-based switching regardless of event boundaries.

**`phoneHomeIntervalInSecs`** - configured in `deploymentclient.conf` on the **forwarders** to control how often they check in with the Deployment Server. To change from the default 60 seconds to hourly: deploy `deploymentclient.conf` to forwarders with `phoneHomeIntervalInSecs = 3600`.

**Enabling compression on a Universal Forwarder:**

```ini
[tcpout]
defaultGroup = my_indexers
compressed = true
```

**Wait queue size with useACK:** If `useACK = true` and `maxQueueSize = 7MB`, the wait queue size is `3 x 7MB = 21MB`. Three queues are maintained: input, send, and wait.

**`_TCP_ROUTING`** in `inputs.conf` allows routing specific data streams to specific indexers or indexer groups.

**To check which indexer(s) are being used by a forwarder:** `splunk list forward-server`

**`splunk add forward-server indexer:<port>`** creates stanzas in `outputs.conf`.

**`splunk set deploy-poll deployServer:port`** creates `deploymentserver.conf` in `$SPLUNK_HOME/etc/system/local`.

**Data distribution check:** Run `index=*` and check the `splunk_server` field to see which indexer each event is stored on. This confirms even distribution across indexers.

---

### 5.8 Data Masking with props.conf and transforms.conf

**To mask SSN or sensitive data at index time using transforms.conf:**

```ini
[mask-SSN]
REGEX = (?ms)^(.)\<[SSN>\d{3}-?\d{2}-?(\d{4}.*)$"
FORMAT = $1<SSN>###-##-$2
DEST_KEY = _raw
```

Then in `props.conf`, reference it with `TRANSFORMS-maskssn = mask-SSN`.

**Required stanza attributes in transforms.conf for event manipulation/masking:**

- `REGEX` - the regular expression pattern
- `DEST_KEY` - the destination field (use `_raw` to modify raw event data)
- `FORMAT` - the replacement format

`DEST`, `SRC_KEY`, and `FORMATTING` are not the correct attribute names.

**`SHOULD_LINEMERGE = false`** - for single-line event sourcetypes, set this to `false` to avoid the overhead of the line merge process. Default is `true`.

**`SHOULD_LINEMERGE = true`** - enables Splunk to merge multiple lines into a single event. Required for multiline log formats.

**`LINE_BREAKER`** - configured in `props.conf`. Default value: `([\r\n]+)`. This means one or more carriage returns or newlines delineate events.

**`MAX_TIMESTAMP_LOOKAHEAD`** - determines how many characters Splunk looks ahead to find a timestamp. For timestamps at or near the start of events, a value of 30 provides sufficient buffer for slight variations.

---

### 5.9 Timezone Handling

**Timezone applied to events during indexing:** The **timezone of the indexer** that indexed the event determines the timezone stored. However, if the forwarder's inputs.conf specifies a timezone and the timestamp lacks timezone information, **the timezone of the forwarder** is used to interpret ambiguous timestamps.

---

## Chapter 6: Deployment Server

### 6.1 How the Deployment Server Works

The relationship is a **pull model** - Forwarders poll the Deployment Server. Apps are deployed from `$SPLUNK_HOME/etc/deployment-apps` on the Deployment Server to `$SPLUNK_HOME/etc/apps` on the clients.

**Deployment Server use case:** Updating configurations and distributing apps to processing components, primarily forwarders.

**Deployment Server capabilities:**

- Requires Enterprise license
- Sends apps to forwarders
- Can automatically restart remote Splunk instances after configuration deployment
- Does NOT restart the host operating system

**Server Classes:** The attribute in forwarder management that determines which apps clients install is **Server Class** (configured in `serverclass.conf`). Apps are mapped to clients through the **Server Classes tab** in forwarder management, or via `serverclass.conf`.

**Where deployment server apps are mapped to clients:** Server Classes tab in forwarder management interface or `serverclass.conf`.

**App location on Deployment Server before deployment:** `$SPLUNK_HOME/etc/deployment-apps`

**After deployment, apps land on clients at:** `$SPLUNK_HOME/etc/apps`

**Forwarder Management in Splunk Web is enabled by:** Placing an app in `$SPLUNK_HOME/etc/deployment-apps` on the Deployment Server.

---

### 6.2 Configuring a Forwarder to Register with the Deployment Server

```bash
sudo /opt/splunkforwarder/bin/splunk set deploy-poll <DEPLOYMENT_SERVER_IP>:8089
```

Or create `deploymentclient.conf` directly:

```ini
[target-broker:deploymentServer]
targetUri = <DEPLOYMENT_SERVER_IP>:8089

[deployment-client]
phoneHomeIntervalInSecs = 60
```

After creating or editing `deploymentclient.conf`, the **next step is to restart Splunk on the deployment client** to enable communication.

**Methods to connect a deployment client to a deployment server:**

- Edit `deploymentclient.conf` in `$SPLUNK_HOME/etc/system/local` on the deployment client
- Run `splunk set deploy-poll <server>:<port>` from the command line of the **deployment client** (not the server)

**Configuring a deployment client:** `splunk set deploy-poll` - this is the correct command. (`splunk set client-poll`, `splunk set config-client`, `splunk set deploy-client` are not valid commands.)

---

### 6.3 Creating and Deploying Apps

```bash
mkdir -p /opt/splunk/etc/deployment-apps/linux_inputs/local
nano /opt/splunk/etc/deployment-apps/linux_inputs/local/inputs.conf
```

**Ensure successful deployment after editing a config file in a deployed app:**

1. Make the change in `$SPLUNK_HOME/etc/deployment-apps/$appName/local/` on the Deployment Server
2. Run `$SPLUNK_HOME/bin/splunk reload deploy-server`

Reloading the deploy-server is required to refresh the in-memory list of deployable apps so clients receive the updated package on their next check-in.

**Editing `$SPLUNK_HOME/etc/apps/$appName/local/` on a deployment client and running reload does NOT propagate changes to the Deployment Server.** The architecture is server-push to clients only.

---

### 6.4 Remote Monitor Input Distribution

A remote monitor input is distributed to forwarders **as an app**. Apps bundle the `inputs.conf` configuration and are distributed through the Deployment Server, providing versioning, centralized management, and simplified rollout.

---

### 6.5 Upgrade-Safe Configuration Editing

**To ensure changes survive an upgrade to a TA (Technology Add-on):** Edit `$SPLUNK_HOME/etc/apps/Splunk_TA_nginx/local/inputs.conf` - not the `default/` directory, which gets overwritten during upgrades.

---

## Chapter 7: Splunk Processing Language (SPL)

### 7.1 How SPL Executes

A query is processed strictly left to right. The first clause retrieves events from the index. Every subsequent pipe command transforms the result set from the previous step.

**Where `outputlookup` executes in a distributed environment:** On the **Search Head**. `outputlookup` is a search-head-only command that writes lookup files and runs where lookup knowledge objects and the lookup filesystem namespace are managed.

---

### 7.2 Search Basics

```splunk
index=linux
index=linux failed
index=linux sourcetype=linux_secure user=root
index=linux (failed OR invalid) NOT localhost
index=linux src_ip=192.168.*
index=linux earliest=-24h latest=now
```

**`splunk_server`** - field to check for data distribution across indexers. Run `index=*` and group by `splunk_server` to see which indexer holds which events.

**`splunk_server_group`** - used in searches to target a specific group of distributed search peers. Configured in `distsearch.conf`.

---

### 7.3 Field Manipulation

```splunk
| fields host, source, _time, user
| fields - _raw
| dedup EventID
| rename User AS employee_name
| eval is_admin = if(user="admin", "yes", "no")
| eval severity = case(EventCode=4625, "low", EventCode=4648, "medium", EventCode=4672, "high", 1=1, "unknown")
```

---

### 7.4 Statistical Aggregation

```splunk
index=linux | stats count
index=linux | stats count BY user
index=linux | stats count, dc(src_ip) AS unique_ips, max(_time) AS last_seen BY user
```

---

### 7.5 User Search Filters

When a user is assigned two roles with different search filters, the combined filter uses **OR** logic: `srchFilter = ((sourcetype=csv) OR (sourcetype!=json AND index=main))`

---

## Chapter 8: Apps, Add-ons, and User Management

### 8.1 Apps vs Add-ons

**Apps** include a user interface: dashboards, saved searches, navigation menus. They live under `/opt/splunk/etc/apps/`.

**Technology Add-ons (TAs)** have no UI. They contain configuration that teaches Splunk how to parse a specific data source.

---

### 8.2 User Roles and Access Control

|Role|Capabilities|
|---|---|
|`user`|Basic searching. Can access authorized indexes and apps.|
|`power`|Can create saved searches, edit shared objects and alerts. Cannot create custom roles.|
|`admin`|Full administrative access, including creating custom roles.|
|`can_delete`|Can execute the `delete` command.|

**Role inheritance** - allows one role to inherit the capabilities and permissions of another role. Used to aggregate multiple roles for groups of users. This is the feature to use to aggregate multiple roles.

**Grantable roles** - allows users to grant a role to other users. Not the same as aggregation.

**What is a role in Splunk:** A classification that determines (1) what indexes a user can search and (2) what capabilities a user has. Roles do not determine if a Splunk server can control another server.

**Valid methods to create a Splunk user:** API (REST API), CLI, Splunk Web. Adding to `users.conf` or creating an OS user are not valid methods.

**Minimum required settings when creating a native Splunk user:** Username and Password. Full Name and Default App are not required.

---

### 8.3 Splunk Data Preview Feature

**Data Preview** is used for **validating the parsing of data**. It allows you to see how Splunk parses incoming data - timestamps, event breaking, field extraction - before committing the data to an index. It validates transformations that change the sourcetype.

It is NOT used for:

- Reviewing data on the source host
- Extracting fields for already ingested data
- Previewing data before searching

**The Upload option** in Add Data is the best way to test data ingestion without creating `inputs.conf`. It allows one-time file upload and immediate preview without persistent inputs.

---

## Chapter 9: Authentication and Multi-Factor

### 9.1 Native Splunk Authentication

**Disabling native authentication:** Create an **empty** `$SPLUNK_HOME/etc/passwd` file. This signals Splunk that there are no local users, forcing it to rely on external authentication methods. Deleting the file entirely may cause errors. Setting `nativeAuthentication=false` in `authentication.conf` may not fully disable it in all versions.

**When the same username exists in both Splunk native and LDAP:** Splunk settings take precedence. The local Splunk configuration overrides LDAP for that username.

---

### 9.2 LDAP Integration

**Defining user permissions when integrating Splunk with LDAP:** **Map Groups** - LDAP groups are mapped to Splunk roles. This is the primary mechanism for permission management. Mapping individual users is not the primary approach.

**Splunk LDAP authentication behavior:**

- Splunk **checks the LDAP server each time a user logs in** (not on a fixed timer, not only on restart)
- Splunk searches each LDAP strategy **in the order in which they are listed** in `authentication.conf`
- LDAP group names do NOT need to match Splunk role names exactly - they are mapped via configuration
- Splunk supports both encrypted (LDAPS) and unencrypted (LDAP) connections
- Local Splunk users take precedence over LDAP users with the same username

**When integrated with LDAP, the attribute that can be changed in the Splunk UI for an LDAP user:** Default App only. Username, Password, and LDAP group cannot be changed in Splunk for LDAP users.

---

### 9.3 SAML Authentication

SAML enables Single Sign-On and inherently supports multi-factor authentication through integration with Identity Providers that implement multiple authentication factors.

---

### 9.4 RADIUS Authentication

RADIUS authentication **requires scripting** in Splunk. Unlike LDAP and SAML, which have pre-built configurations, RADIUS requires custom scripts to translate RADIUS responses into Splunk-usable authentication data.

---

### 9.5 Natively Supported Authentication Methods in Splunk Enterprise

- LDAP
- SAML
- Duo Multifactor Authentication

**RADIUS is NOT natively supported** for user authentication in Splunk Enterprise.

**Multi-factor authentication works with:**

- RADIUS
- LDAP
- Native authentication

**MFA does NOT work with:** Scripted authentication (not natively supported with Duo).

---

### 9.6 Duo Multifactor Authentication

**Application Secret, Integration key, Secret key, and API Hostname are provided by:** the **Duo Administrator**.

**Correct order of Duo MFA steps:**

1. Request Login
2. Check authentication / group mapping
3. Authentication Granted (conditional)
4. Duo MFA
5. Create User session
6. Log into Splunk

**`failOpen = true`** in `authentication.conf` - if Splunk cannot connect to the Duo MFA provider, authentications succeed without completing a multifactor challenge.

---

## Chapter 10: Distributed Search

### 10.1 How Distributed Search Works

In distributed search:

- The **search head dispatches searches** to the search peers
- **Peers run searches in parallel** and return their portion of results
- The **search head consolidates the individual results** and prepares reports
- Forwarders do NOT pull data from search peers
- Search heads do NOT store searchable data
- Search results are NOT replicated within the indexer cluster as part of distributed search

**Benefit of distributed search:** Peers run searches in parallel, dramatically reducing search time for large data volumes.

---

### 10.2 distsearch.conf Configuration

To configure distributed search groups and allow `splunk_server_group=HOUSTON`:

```ini
[distributedSearch]
servers = nyc1:8089, nyc2:8089, houston1:8089, houston2:8089

[distributedSearch:NYC]
default = false
servers = nyc1:8089, nyc2:8089

[distributedSearch:HOUSTON]
default = false
servers = houston1:8089, houston2:8089
```

**Key requirements:**

- Servers must be specified with the **management port (8089)**, not the data port (9997)
- Servers in the global `[distributedSearch]` stanza are comma-separated
- Group stanzas use format `[distributedSearch:<groupname>]`
- `default = false` means this is not the default search group
- Servers separated by **semicolons** (not commas) is valid in some contexts

**Configuration file for distributed search groups:** `distsearch.conf` (not `distributedsearch.conf`, `props.conf`, or `search.conf`).

**Valid distributed search group stanza:**

```ini
[distributedSearch:Paris]
default = false
servers = server1:8089; server2:8089
```

---

### 10.3 Knowledge Bundles

**Knowledge bundles are distributed to search peers when:** a distributed search is initiated. The search head packages knowledge objects (field extractions, event types, lookups, tags) into a bundle and sends it to participating search peers just before the search executes.

---

### 10.4 Search Head Compatibility with Search Peers

**Search heads must be at the same version or higher than the search peers.** Search heads are backward-compatible with older search peers. An older search head cannot handle newer indexer features or data formats, which would cause search failures.

---

### 10.5 Accessing Specific Indexers from Remote Offices

**To allow European search heads to search New York indexers and restrict access to certain indexers:** Configure **Distributed Search**. Distributed search allows a search head to federate search jobs to remote indexers and selectively target specific search peers through peer lists and access controls.

---

## Chapter 11: Licensing

### 11.1 License Types

**Enterprise Trial license:** Valid for **60 days** before automatically converting to a Free license. Provides full Enterprise functionality including up to 500 MB/day indexing.

**Free license:** Limited functionality - no user authentication, no distributed search.

**Forwarder license:** Required by Heavy Forwarders (due to their parsing and indexing capabilities). Universal Forwarders have a built-in license.

**What is pre-selected in a brand new Splunk installation:** Enterprise Trial license.

---

### 11.2 License Violations

**After how many warnings within a rolling 30-day period will a license violation occur with an enforced Enterprise license:** 5 warnings. After the fifth warning, Splunk restricts search functionality.

**License data counted at a fixed 150 bytes per event:** Metrics data. Regular log data is counted by actual indexed size. Metrics data uses a fixed 150-byte per-event calculation regardless of actual size.

**What counts against the license daily quota:** Windows internal logs, application logs, and most external data. The following are NOT counted or exempt: replicated data (not counted twice), `splunkd` internal logs (not counted), summary index data (counted, but pre-aggregated so smaller volume).

**License metering phase:** Indexing phase.

**License file location:** `$SPLUNK_HOME/etc/licenses`.

**License pool volume allocations apply to:** Indexers only. Indexers are the components that actually ingest and index data against which license volume is measured.

---

### 11.3 Adding Historical Data with License Constraints

**Best way to add 10 TB of historical data with a 500 GB/day license (current usage 300 GB/day):** Add all 10 TB in a single 24-hour period. Splunk treats a one-day spike as an anomaly. Spreading it over multiple days guarantees repeated license violation warnings.

---

### 11.4 License Warning Prevention

**To prevent a license warning with an ingest-based license:** Add a new license **before midnight on the license manager**. The license manager is where daily volume is tracked and enforcement occurs. Adding the license before the daily reset gives Splunk time to recognize increased capacity.

---

## Chapter 12: Monitoring Console and Forwarder Health

### 12.1 Monitoring Forwarders

The Monitoring Console monitors forwarders using **internal logs forwarded by the forwarders themselves** (not by pulling logs or using add-ons).

**To remove missing forwarders from the Monitoring Console:** Rebuild the forwarder asset table.

**To check which forwarders are connected:** Monitor Console > Forwarder Monitoring shows every connected forwarder, last-seen time, and data volume.

---

### 12.2 Internal Index Diagnostics

```splunk
index=_internal sourcetype=splunkd log_level=ERROR
| table _time, component, message
| sort -_time

index=_internal source=*metrics.log group=pipeline name=indexer
| timechart avg(eps) AS events_per_second

index=_internal source=*metrics.log group=tcpin_connections
| stats max(_time) AS last_seen BY hostname
| eval hours_since = (now() - last_seen) / 3600
| where hours_since > 1
```

---

## Chapter 13: Sysmon and Windows Log Collection

### 13.1 Why Sysmon

Windows Security Event ID 4688 (Process Creation) exists but requires additional GPO configuration to log command lines, and it never logs process hashes. Sysmon Event ID 1 (Process Create) logs the full command line, parent process name and GUID, user context, and MD5/SHA256 hashes of the executed binary.

---

### 13.2 Forwarding Windows Event Logs

```ini
[WinEventLog://Security]
disabled = 0
index = windows
start_from = oldest
current_only = 0

[WinEventLog://Microsoft-Windows-Sysmon/Operational]
disabled = 0
index = windows

[WinEventLog://Microsoft-Windows-PowerShell/Operational]
disabled = 0
index = windows

[WinEventLog://System]
disabled = 0
index = windows
```

**Windows Remote Inputs with WMI** - use `wmi.conf` to configure collection of Windows performance data from remote hosts **without installing Splunk** on the monitored endpoints.

---

## Chapter 14: Detection Use Cases

### 14.1 Multiple Failed Login Attempts

```splunk
index="windows" EventCode=4625
| stats count BY Account_Name
| where count > 5
    AND NOT match(Account_Name, ".*\\$")
| sort -count
| table Account_Name, count
```

---

### 14.2 PowerShell Cmdlet Execution

```splunk
index="windows" EventCode=4104
| where NOT match(Command, "prompt")
| where match(Command, "^[A-Z][a-z]+-([A-Z]{2,}|[A-Z][a-z]+)+")
| where NOT match(Command, "^\\s*\\{")
| where isnotnull(Command)
| table _time, host, Command
| sort -_time
```

---

### 14.3 Brute Force Then Successful Login

```splunk
index="windows" EventCode=4625
| stats count AS failures BY Account_Name
| where failures > 10
    AND NOT match(Account_Name, ".*\\$")
| join Account_Name
    [search index="windows" EventCode=4624
     | stats count AS successes BY Account_Name]
| table Account_Name, failures, successes
| sort -failures
```

---

## Chapter 15: Health Monitoring and Operational Practices

### 15.1 Diagnosing Splunk with the _internal Index

```splunk
index=_internal sourcetype=splunkd log_level=ERROR
| table _time, component, message
| sort -_time

index=_internal source=*metrics.log group=queue
| stats avg(current_size_kb), avg(max_size_kb) BY name
| eval fill_pct = round(avg(current_size_kb) / avg(max_size_kb) * 100, 1)
| sort -fill_pct
```

---

### 15.2 Data Backup

Two directories must be backed up:

- `/opt/splunk/etc` - all configuration files, apps, user accounts, knowledge objects
- `/opt/splunk/var/lib/splunk` - all indexed data

---

### 15.3 Deleting Data

```splunk
index=linux host=test_server | delete
```

```bash
/opt/splunk/bin/splunk clean eventdata -index test_index -f
```

---

## Chapter 16: Detection Engineering Framework

### 16.1 Start with Use Cases, Not Queries

|Field|Description|
|---|---|
|**Goal**|The specific threat actor action being detected.|
|**Data sources**|The specific index, sourcetype, and event IDs required.|
|**Detection logic**|The SPL query that identifies the behavior.|
|**Known false positives**|Legitimate activity that the query will also flag.|
|**Tuning plan**|How to reduce false positives without eliminating true positives.|
|**Severity**|Critical / High / Medium / Low.|
|**Triage steps**|First three things an analyst should check.|
|**Evidence to collect**|Data to gather to confirm or deny the alert.|
|**Response action**|Immediate response if confirmed malicious.|

---

### 16.2 Log Source Coverage Assessment

```splunk
| tstats count WHERE index=* BY index, sourcetype, host
| sort -count

index=* earliest=-25h latest=-1h
| stats max(_time) AS last_event BY index, sourcetype, host
| eval hours_silent = (now() - last_event) / 3600
| where hours_silent > 24
| table index, sourcetype, host, hours_silent
| sort -hours_silent
```

---

## Appendix: Quick Reference

### Default Ports

|Service|Port|Protocol|
|---|---|---|
|Splunk Web UI|8000|TCP|
|Splunk Management API|8089|TCP|
|Forwarder to Indexer (receiving)|9997|TCP|
|HTTP Event Collector (HEC)|8088|TCP|
|Deployment Server (phone home)|8089|TCP|
|Indexer replication (clustering)|9887|TCP|
|KV Store (Search Head cluster)|8191|TCP|

---

### Key File and Directory Locations

|Path|Purpose|
|---|---|
|`/opt/splunk/bin/splunk`|Main Splunk executable|
|`/opt/splunk/etc/`|Parent directory of all configuration files|
|`/opt/splunk/etc/system/local/`|System-level config overrides - highest precedence at index time|
|`/opt/splunk/etc/system/default/`|Splunk factory defaults - lowest precedence|
|`/opt/splunk/etc/apps/`|All installed apps; where deployed apps land on clients|
|`/opt/splunk/etc/deployment-apps/`|Apps staged for distribution to Forwarders|
|`/opt/splunk/etc/master-apps/`|Apps for indexer cluster peers|
|`/opt/splunk/etc/licenses/`|License files|
|`/opt/splunk/var/lib/splunk/`|All indexed data (buckets); also `$SPLUNK_DB`|
|`/opt/splunk/var/log/splunk/splunkd.log`|Main Splunk daemon log|
|`/opt/splunk/var/log/splunk/audit.log`|User activity audit trail|
|`/opt/splunkforwarder/etc/apps/`|Apps on Universal Forwarder|
|`/opt/splunk/etc/splunk-launch.conf`|Environment variables including `SPLUNK_DB` path|

---

### Configuration Precedence Summary

**Index-time (global context) - highest to lowest:**

1. `system/local`
2. App `local` directories
3. App `default` directories
4. `system/default`

**Search-time - highest to lowest:**

1. User context (`users/<user>/<app>/local`)
2. App `local`
3. App `default`
4. `system/local`
5. `system/default`

Users directory is never considered in the index-time global context.

---

### Exam-Critical Facts

|Topic|Fact|
|---|---|
|License metering phase|Indexing phase|
|Warm to Cold trigger|Maximum number of warm buckets (`maxWarmDBCount`) is reached|
|Searchable bucket types|Hot, Warm, Cold (NOT frozen)|
|frozenTimePeriodInSecs|Controls data retention by time in indexes.conf|
|Fishbucket reset location|On the Forwarder (not the Indexer)|
|Pre-configured indexes|`_internal` and `_thefishbucket`|
|UF capabilities|Compress data, indexer acknowledgement (NOT alerts, NOT obfuscation)|
|Heavy forwarder license|Requires Forwarder license|
|UF built-in license|Has its own built-in license|
|Deployment Server license|Requires Enterprise license|
|Deployer purpose|Push apps to Search Head cluster members|
|Deployment Server purpose|Push apps to Forwarders|
|Cluster Manager purpose|Manage indexer cluster replication|
|distsearch.conf|Sets up distributed search groups|
|Knowledge bundles distribution|When a distributed search is initiated|
|SHC compatibility|Search heads must be same version or higher than search peers|
|SEDCMD location|props.conf|
|SEDCMD purpose|Modify raw data at index time|
|transforms.conf required attributes|REGEX, DEST_KEY, FORMAT|
|LINE_BREAKER location|props.conf|
|LINE_BREAKER default|`([\r\n]+)`|
|SHOULD_LINEMERGE=false|Set for single-line sourcetypes for efficiency|
|SHOULD_LINEMERGE=true|Required for multiline event handling|
|ignoreOlderThan|Monitor stanza attribute to skip old data|
|followTail|Monitor files for updates without indexing existing data|
|interval=0 (scripted)|Script restarted immediately upon exit - continuous execution|
|Whitelist/Blacklist filtering|Uses regular expressions|
|Blacklist vs whitelist|Blacklist takes precedence|
|HEC endpoint|`services/collector`|
|HEC required header|Token (Authorization: Splunk <token>)|
|HEC channel value|GUID|
|Native auth disable|Create empty passwd file|
|LDAP check frequency|Each time a user logs in|
|LDAP precedence|Local Splunk users take precedence over LDAP|
|RADIUS|Requires scripting|
|Duo keys provided by|Duo Administrator|
|Duo MFA failOpen|Bypasses MFA when Duo service unavailable|
|MFA supported methods|RADIUS, LDAP, Native auth|
|MFA not supported|Scripted authentication|
|Natively supported auth|LDAP, SAML, Duo|
|Enterprise Trial duration|60 days|
|License violation threshold|5 warnings in 30 days|
|Metrics data licensing|150 bytes per event (fixed)|
|License files location|`$SPLUNK_HOME/etc/licenses`|
|deployment-apps location|`$SPLUNK_HOME/etc/deployment-apps` on Deployment Server|
|deploymentclient.conf|Created in `$SPLUNK_HOME/etc/system/local` by `set deploy-poll`|
|Server class purpose|Maps apps to client groups|
|serverclass.conf|Where app-to-client mappings are defined|
|Forwarder management enabled by|Placing an app in deployment-apps|
|splunk set deploy-poll|Configures deployment client|
|After deploymentclient.conf created|Restart Splunk on the deployment client|
|Remote monitor distribution|As an app|
|CHARSET best practice|Use source-level stanza (`[source:://path]`)|
|autoLBFrequency|Controls indexer switching interval|
|forceTimebasedAutoLB|Forces time-based switching on busy syslog streams|
|phoneHomeIntervalInSecs|In deploymentclient.conf on forwarders|
|Monitoring Console data|Internal logs forwarded by forwarders|
|Missing forwarder removal|Rebuild forwarder asset table|
|WMI config file|wmi.conf|
|WMI use case|Windows performance data without installing Splunk|
|Data distribution check|Search `index=*`, check `splunk_server` field|
|Upgrade-safe config edits|Always edit app `local/` directory, never `default/`|
|outputlookup execution|Search Head|
|props.conf valid stanzas|host, source, sourcetype (NOT server, NOT index)|

---

### Windows Event IDs for Security Monitoring

|Event ID|Description|Log|
|---|---|---|
|4624|Successful logon|Security|
|4625|Failed logon attempt|Security|
|4648|Logon using explicit credentials|Security|
|4672|Privileged logon|Security|
|4688|Process creation|Security|
|4698|Scheduled task created|Security|
|4720|User account created|Security|
|4728 / 4732|Member added to a security group|Security|
|7045|New service installed|System|
|1 (Sysmon)|Process creation with hashes|Sysmon/Operational|
|3 (Sysmon)|Network connection|Sysmon/Operational|
|11 (Sysmon)|File created|Sysmon/Operational|
|13 (Sysmon)|Registry value set|Sysmon/Operational|
|4104|PowerShell script block executed|PowerShell/Operational|
