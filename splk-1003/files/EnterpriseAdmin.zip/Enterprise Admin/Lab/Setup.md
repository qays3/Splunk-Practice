
## Splunk Lab Setup — Ubuntu 24.04.4 LTS

---

### Lab Architecture

```
Host Machine (VirtualBox/VMware)
    |
    |-- Indexer VM (Splunk Enterprise + Search Head)
    |       receives logs on port 9997 (UF)
    |       web UI on port 8000
    |
    |-- Web Server VM (Ubuntu + UFW + Universal Forwarder)
            UFW firewall logs + system logs shipped to Indexer
```

---

## Part 1 — Indexer VM (Splunk Enterprise)

### Step 1 — Download Splunk Enterprise

Go to: https://www.splunk.com/en_us/download/splunk-enterprise.html

Register a free account → Download the .deb package for [Linux (x86_64).](wget -O splunk-10.2.2-80b90d638de6-linux-amd64.deb "https://download.splunk.com/products/splunk/releases/10.2.2/linux/splunk-10.2.2-80b90d638de6-linux-amd64.deb")

---

### Step 2 — Install Splunk Enterprise

```bash
sudo dpkg -i splunk-*.deb
```

---

### Step 3 — Start Splunk & Accept License

```bash
sudo /opt/splunk/bin/splunk start --accept-license --answer-yes --run-as-root --no-prompt --seed-passwd hidden93
```

Web UI: http://splk:8000/

---

### Step 4 — Enable Splunk on Boot

```bash
sudo /opt/splunk/bin/splunk enable boot-start --run-as-root
```

---

### Step 5 — Enable Indexer Listening on Port 9997

```bash
sudo chmod -R 777 /opt/splunk/var
sudo chmod -R 777 /opt/splunk/etc
sudo mkdir -p /opt/splunk/.splunk
sudo chmod -R 777 /opt/splunk/.splunk
sudo /opt/splunk/bin/splunk enable listen 9997 --run-as-root -auth admin:hidden93
```

If boot-start fails on reboot:

```bash
sudo chmod -R 777 /opt/splunk
sudo /opt/splunk/bin/splunk start --run-as-root
```

---

## Part 2 — Web Server VM (UFW + Universal Forwarder)

### Step 6 — Enable UFW and Logging

```bash
sudo ufw enable
sudo ufw logging full
sudo ufw allow ssh
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp
```

UFW logs go to: /var/log/ufw.log

---

### Step 7 — Verify UFW Logs Are Being Written

```bash
sudo tail -f /var/log/ufw.log
```

---

### Step 8 — Download Universal Forwarder

Go to: https://www.splunk.com/en_us/download/universal-forwarder.html

Download the .deb for [Linux (x86_64).](wget -O splunkforwarder-10.2.2-80b90d638de6-linux-amd64.deb "https://download.splunk.com/products/universalforwarder/releases/10.2.2/linux/splunkforwarder-10.2.2-80b90d638de6-linux-amd64.deb")

---

### Step 9 — Install Universal Forwarder

```bash
sudo dpkg -i splunkforwarder-*.deb
```

---

### Step 10 — Start Forwarder & Accept License

```bash
sudo /opt/splunkforwarder/bin/splunk start --accept-license --answer-yes --run-as-root --no-prompt --seed-passwd hidden93
```

---

### Step 11 — Point Forwarder to Indexer

```bash
sudo /opt/splunkforwarder/bin/splunk add forward-server INDEXER_IP:9997 --run-as-root -auth admin:hidden93
```

---

### Step 12 — Add Log Sources to Monitor

```bash
sudo /opt/splunkforwarder/bin/splunk add monitor /var/log/ufw.log --run-as-root -index main -auth admin:hidden93
sudo /opt/splunkforwarder/bin/splunk add monitor /var/log/syslog --run-as-root -index main -auth admin:hidden93
sudo /opt/splunkforwarder/bin/splunk add monitor /var/log/auth.log --run-as-root -index main -auth admin:hidden93
sudo /opt/splunkforwarder/bin/splunk add monitor /var/log/kern.log --run-as-root -index main -auth admin:hidden93
sudo /opt/splunkforwarder/bin/splunk add monitor /var/log/dpkg.log --run-as-root -index main -auth admin:hidden93
```

If web server (Apache):

```bash
sudo /opt/splunkforwarder/bin/splunk add monitor /var/log/apache2/access.log --run-as-root -index main -auth admin:hidden93
sudo /opt/splunkforwarder/bin/splunk add monitor /var/log/apache2/error.log --run-as-root -index main -auth admin:hidden93
```

If web server (Nginx):

```bash
sudo /opt/splunkforwarder/bin/splunk add monitor /var/log/nginx/access.log --run-as-root -index main -auth admin:hidden93
sudo /opt/splunkforwarder/bin/splunk add monitor /var/log/nginx/error.log --run-as-root -index main -auth admin:hidden93
```

---

### Step 13 — Enable Forwarder on Boot

```bash
sudo /opt/splunkforwarder/bin/splunk enable boot-start --run-as-root
```

---

### Step 14 — Restart Forwarder

```bash
sudo /opt/splunkforwarder/bin/splunk restart --run-as-root
```

---

## Part 3 — Verify on Splunk Web UI

1. Open: http://splk:8000/
2. Login: admin / hidden93
3. Go to: Search & Reporting
4. Search for UFW firewall logs:

```
index=main source="/var/log/ufw.log"
```

5. Search for all Linux logs:

```
index=main sourcetype=syslog
```

---

## After 2-Month Trial — Keep Free with 500MB/day Limit

When the trial expires Splunk reverts to the free license automatically (500MB/day ingest).

To confirm: Settings → Licensing → verify Splunk Free.

No action needed — it downgrades itself. All forwarder setup keeps working.