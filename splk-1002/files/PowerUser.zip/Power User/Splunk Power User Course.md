## Exam Blueprint Domains

1. Using Transforming Commands for Visualizations
2. Filtering and Formatting Results
3. Correlating Events
4. Creating and Managing Fields
5. Creating Field Aliases and Calculated Fields
6. Creating Tags and Event Types
7. Creating and Using Macros
8. Creating and Using Workflow Actions
9. Creating Data Models
10. Using the Common Information Model (CIM)

---

# Domain 1 Using Transforming Commands for Visualizations

## What are Transforming Commands?

Transforming commands take your search results and transform them into a statistical table or data structure that can be visualized. They must appear after the pipe in a search. Without a transforming command, Splunk returns raw events. With one, you get aggregated, structured output suitable for charts, tables, and dashboards. Transforming commands are the foundation of every visualization in Splunk — no chart can exist without one.

---

## SPL Command Types

|Type|Description|Examples|
|---|---|---|
|Distributable Streaming|Processes each event individually; can run on indexers in parallel — order does not matter|`eval`, `fields`, `where`, `rename`, `regex`, `replace`, `strcat`, `lookup`|
|Centralized Streaming|Processes each event individually but requires event ordering — runs only on search head|`head`, `streamstats`, `dedup` (some modes), `cluster` (some modes)|
|Transforming|Converts results into a data table with numerical values for stats/visualization|`stats`, `chart`, `timechart`, `top`, `rare`, `geostats`|
|Generating|Generates or returns data without requiring input; used at start of search with leading pipe|`search`, `inputlookup`, `makeresults`, `metadata`, `tstats`, `datamodel`|
|Orchestrating|Controls how a search is processed; does not directly affect result set|`map`, `sendemail`|
|Dataset Processing|Requires the entire dataset before running; not streaming, not transforming|`sort`, `eventstats`, `fillnull` (some modes), `cluster` (some modes), `dedup` (some modes)|

Understanding command types matters because distributable streaming commands like `eval` and `fields` can be pushed down to indexers, which improves performance at scale. Transforming commands like `stats` and `chart` must consolidate data, so they run on the search head after the indexers return their results.

---

## The `chart` Command

Used to create a table with an X axis (over field) and Y axis (statistical function). The `over` clause defines the x-axis column values; the `by` clause defines the series (rows/lines). A comma-separated list after `by` achieves the same multi-dimensional grouping as using `over` and `by` separately — `| chart count by vendor_action, user` produces identical results to `| chart count over vendor_action by user`.

```splunk
index=web_logs
| chart count by status
```

Expected output:

|status|count|
|---|---|
|200|45230|
|404|1823|
|500|412|

```splunk
index=web_logs
| chart count by status, host
```

Expected output — each unique `host` becomes a column; each `status` value is a row:

|status|webserver01|webserver02|webserver03|
|---|---|---|---|
|200|15000|18000|12230|
|404|600|800|423|
|500|100|200|112|

```splunk
index=web_logs
| chart avg(response_time) over host by status
```

This places `host` on the x-axis and creates one line per `status` value showing average response time.

```splunk
index=web_logs
| chart count by status limit=5 useother=false
```

Key Options:

- `limit=<N>` limits number of series displayed (default 10)
- `useother=false` removes the "OTHER" catch-all bucket that groups values beyond the limit
- `usenull=false` removes NULL values from chart

To display a chart in stack mode, change Stack Mode in the Format menu of the visualization editor. Trellis layout splits a chart into multiple smaller charts — it does not stack. These are two distinct visualization options that are commonly confused on the exam.

---

## The `timechart` Command

Like `chart` but always plots over time on the X axis. The `_time` field is automatically used as the x-axis — you never specify it explicitly. Because `_time` is already implied as the x-axis, only one field can follow a `by` clause in `timechart`. Attempting to add two fields after `by` is a syntax error.

```splunk
index=web_logs
| timechart count
```

Expected output — a time-series table where each row is a time bucket and the single column is `count`:

|_time|count|
|---|---|
|2024-01-01 00:00|342|
|2024-01-01 01:00|287|
|2024-01-01 02:00|198|

```splunk
index=web_logs
| timechart count by status
```

Expected output — one column per distinct status value:

|_time|200|404|500|
|---|---|---|---|
|2024-01-01 00:00|300|35|7|
|2024-01-01 01:00|250|28|9|

```splunk
index=web_logs
| timechart span=1h avg(response_time) by host
```

The `span` argument is the correct and only argument for controlling time bucket size in `timechart`. The `duration` argument and `interval` argument do not serve this purpose. `fieldformat` options control display formatting of values, not time bucketing.

Key Options:

- `span=<time>` sets the time bucket size — e.g., `span=1h`, `span=5m`, `span=1d`, `span=30m`
- `limit=<N>` limits series shown
- `useother=false` hides the OTHER bucket

The `span` argument is the answer to "how do you group events into buckets based on time when using timechart." The `duration` and `interval` arguments are distractors.

---

## The `stats` Command

Computes aggregate statistics over your results and returns a clean table. Does not plot automatically — use it when you want a tabular summary without visualization. In large Splunk environments, `stats` is faster and more efficient than `transaction` because it performs in-memory aggregation and can be distributed across indexers, pushing computation closer to the data.

```splunk
index=web_logs
| stats count by status
```

Expected output:

|status|count|
|---|---|
|200|45230|
|404|1823|
|500|412|

```splunk
index=web_logs
| stats count, avg(response_time), max(response_time) by host
```

Expected output:

|host|count|avg(response_time)|max(response_time)|
|---|---|---|---|
|webserver01|15700|0.23|4.12|
|webserver02|19000|0.31|6.80|

```splunk
sourcetype=access_combined
| stats sum(bytes) AS total_bytes by clientip
| sort -total_bytes
| head 10
```

This gives the top 10 IP addresses by total bytes transferred.

```splunk
sourcetype=access_*
| stats count(eval(status=200)) AS success_count, count(eval(status>=400)) AS error_count by host
```

This uses `eval` inside `stats count()` to conditionally count events — a powerful pattern for computing multiple filtered counts in a single pass.

Common stats functions:

- `count` — total number of events
- `count(<field>)` — count of events where field exists and is not null
- `dc(<field>)` — distinct count of unique values
- `sum(<field>)` — sum of all values for that field
- `avg(<field>)` — arithmetic mean
- `min(<field>)` / `max(<field>)` — minimum or maximum value
- `values(<field>)` — multi-value list of distinct values (no duplicates)
- `list(<field>)` — multi-value list of all values including duplicates
- `first(<field>)` / `last(<field>)` — first or last seen value in chronological order
- `median(<field>)` — median value
- `stdev(<field>)` — standard deviation
- `perc<N>(<field>)` — Nth percentile, e.g., `perc95(response_time)`
- `range(<field>)` — max minus min
- `mode(<field>)` — most frequent value

`stats`, `chart`, and `timechart` all support the same set of statistical functions. This is a key exam point — they share the same aggregation function vocabulary. `eval`, `table`, `search`, and `transaction` serve entirely different purposes and do not share this function set.

A space in a search string is an implied AND operator. `index=web_logs status=200 host=webserver01` is equivalent to `index=web_logs AND status=200 AND host=webserver01`.

---

## The `top` and `rare` Commands

```splunk
index=web_logs
| top limit=10 uri
```

Expected output:

|uri|count|percent|
|---|---|---|
|/index.html|8234|18.2%|
|/login|6100|13.5%|

```splunk
index=web_logs
| rare limit=5 status
```

`top` returns the most frequent values with `count` and `percent` columns automatically. `rare` returns the least frequent values with the same columns. Both commands automatically include `count` and `percent` — you do not need to add them manually.

```splunk
index=web_logs
| top limit=5 status by host
```

This shows the top 5 status values grouped by host — `top` also supports a `by` clause.

---

## The `gauge` Command

The `gauge` command allows you to set colored ranges for a single-value visualization. It configures the threshold-based color bands displayed within a single-value panel. It does not create the single-value visualization itself — that is done by `stats count` or similar. `gauge` adds the visual thresholds.

```splunk
index=web_logs
| stats count AS error_count WHERE status>=500
| gauge error_count 0 50 100 200
```

The four numbers define the thresholds for green, yellow, orange, and red ranges. The first number is the minimum, the last is the maximum.

---

## Search Modes and Field Display

|Mode|Behavior|
|---|---|
|Fast|Only returns default fields (`host`, `source`, `sourcetype`). Prioritizes speed. Does not return all extracted fields.|
|Smart|Default mode. Returns fields relevant to the search type — events for non-transforming, fields for transforming.|
|Verbose|Automatically returns all extracted fields in the fields sidebar. Slowest mode.|

Verbose mode is the search mode that automatically returns all extracted fields in the fields sidebar. This is directly tested on the exam — Fast mode returns only default fields, Smart mode adapts based on search type, Verbose mode returns everything.

When a field alias is created and a search without transforming commands runs in Smart Mode, both the original field and the alias appear in the Interesting Fields list — but only if each appears in at least 20% of events returned. Splunk does not separate them into different lists based on whether they are originals or aliases. This threshold behavior is also tested.

The Patterns tab shows event patterns in the results of a specific search. It automatically identifies recurring structures across events, helping analysts quickly find common behaviors. This is distinct from the Statistics and Visualization tabs.

By default, search results are not returned in chronological or alphabetical order — they are returned in reverse chronological order (most recent first).

---

## Exporting Search Results

Using the export function, you can export search results as XML or JSON. HTML and PHP are not supported export formats. This is a hard exam fact — only XML and JSON.

Clicking a segment on a chart adds the highlighted value to the search criteria (drills down by adding it as a filter to the current search).

---

# Domain 2 Filtering and Formatting Results

## The `eval` Command

Creates new fields or overwrites existing ones based on an expression. One of the most powerful and frequently tested SPL commands. The result of an `eval` expression is stored in a field — not in an index, KV Store, or database. These fields are computed at search time and exist only for the duration of the search pipeline.

The `eval` command can:

- Format values (convert timestamps, add commas to numbers, change case)
- Convert values (numeric to string, string to number)
- Perform calculations (arithmetic, math functions, string concatenation)
- Use conditional statements (`if`, `case`)

The knowledge object that represents a saved, reusable eval expression output is a Calculated Field — not "eval fields," not "field extractions," not "calculated lookups." Calculated Field is the specific knowledge object type.

```splunk
index=web_logs
| eval response_kb = response_bytes / 1024
```

Creates a new field `response_kb` containing the size in kilobytes.

```splunk
index=web_logs
| eval status_label = if(status == 200, "OK", "Error")
```

Creates `status_label` with "OK" for 200 responses and "Error" for everything else.

```splunk
index=web_logs
| eval full_name = first_name . " " . last_name
```

String concatenation using the `.` operator.

```splunk
index=web_logs
| eval severity_label = case(
    severity >= 8, "Critical",
    severity >= 5, "High",
    severity >= 3, "Medium",
    1==1, "Low"
)
```

The `case` function evaluates condition-value pairs in order. The final `1==1` acts as a catch-all default (always true).

```splunk
index=web_logs
| eval age_bucket = case(
    age < 18, "minor",
    age < 65, "adult",
    1==1, "senior"
)
```

```splunk
index=web_logs
| eval rounded_time = round(response_time, 2)
| eval size_display = tostring(response_bytes, "commas") . " bytes"
```

The `tostring` function with `"commas"` adds thousands separators: 1234567 becomes "1,234,567". With `"hex"` it converts to hexadecimal. With `"duration"` it converts seconds to a human-readable string like "1d 2h 30m 15s".

Valid `tostring` format arguments: `"hex"`, `"commas"`, `"duration"`. The argument `"decimal"` is not a valid tostring format — this is directly tested. Use `round()` to control decimal places, not tostring.

```splunk
index=web_logs
| eval is_error = if(status >= 400, 1, 0)
| eval is_auth = if(match(uri, "^/login|^/auth"), 1, 0)
```

```splunk
index=web_logs
| eval session_age = now() - session_start
| eval session_age_display = tostring(session_age, "duration")
```

Common eval functions:

|Function|Description|Example|
|---|---|---|
|`if(condition, true, false)`|Conditional|`if(status==200,"ok","fail")`|
|`case(cond1,val1,cond2,val2,...)`|Multi-condition switch|`case(status==200,"ok",status==404,"notfound",1==1,"other")`|
|`round(X,Y)`|Round to Y decimal places|`round(avg_time,2)`|
|`len(X)`|String length|`len(uri)`|
|`lower(X)` / `upper(X)`|Change case|`lower(username)`|
|`substr(X,Y,Z)`|Substring starting at Y, length Z|`substr(uri,1,5)`|
|`replace(X,Y,Z)`|Replace regex pattern Y with Z|`replace(uri,"/old","/new")`|
|`tonumber(X)`|Convert string to number|`tonumber(port)`|
|`tostring(X,Y)`|Convert to string with optional format|`tostring(bytes,"commas")`|
|`now()`|Current epoch time|`now()`|
|`strftime(X,Y)`|Format epoch as human-readable string|`strftime(_time,"%Y-%m-%d")`|
|`strptime(X,Y)`|Parse date string to epoch|`strptime(date,"%Y-%m-%d")`|
|`coalesce(X,Y,...)`|First non-null value in list|`coalesce(username,user,"unknown")`|
|`isnull(X)` / `isnotnull(X)`|Null checks returning true/false|`isnull(src_ip)`|
|`match(X,Y)`|Regex match returning true/false|`match(uri,"^/admin")`|
|`cidrmatch(X,Y)`|CIDR subnet match|`cidrmatch("10.0.0.0/8",src_ip)`|
|`mvcount(X)`|Count values in a multivalue field|`mvcount(tags)`|
|`mvindex(X,Y)`|Get value at index Y from multivalue field|`mvindex(tags,0)`|
|`mvjoin(X,Y)`|Join multivalue field into single string|`mvjoin(tags,",")`|

Valid eval functions include `tostring()`. Functions like `Int()`, `Count()`, and `Print()` are not valid eval functions — they belong to other languages.

### Sorting After eval Conversion

If a user wants to convert numeric field values to strings and also sort on those values, sort first on the numeric values and then convert to string with eval. If you convert to string first, the sort will be lexicographic (alphabetical), causing "10" to sort before "2". Sort numerically first, then convert to string.

```splunk
index=web_logs
| stats count by src_ip
| sort -count
| eval count_display = tostring(count, "commas")
```

This correctly sorts by the numeric `count` field first, then creates a display-friendly string version.

---

## The `where` Command

Filters results using an eval expression. Unlike `search`, `where` evaluates field values as expressions (not strings). Use `where` after `stats` or `eval` to filter computed values.

```splunk
index=web_logs
| stats count by src_ip
| where count > 100
```

Expected output — only src_ip values that generated more than 100 events:

|src_ip|count|
|---|---|
|10.0.0.15|342|
|192.168.1.8|187|

```splunk
index=web_logs
| where like(uri, "/admin%")
```

The `like` function in `where` uses `%` as the wildcard (SQL-style), not `*`.

```splunk
index=web_logs
| where isnull(username)
```

```splunk
index=web_logs
| stats avg(response_time) AS avg_rt by host
| where avg_rt > 1.5
```

The `search` command after `stats` cannot evaluate expressions like `count > 10` on computed fields the same way `where` can — `where` is the correct choice for post-aggregation filtering with conditions.

---

## The `search` Command (inline)

The `search` command behaves exactly like search strings before the first pipe. Before the first `|`, Splunk implicitly treats any keywords or field=value pairs as a `search` command. The `search` command supports wildcards, is case-insensitive by default, and can be used anywhere in the pipeline — not just at the beginning.

```splunk
index=web_logs
| stats count by src_ip
| search count > 50
```

A space in a search string is an implied AND operator. `error login failed` finds events containing all three terms.

The `search` command does not allow wildcards to lead a term (e.g., `*error` does not work as expected), but trailing wildcards work: `err*` matches "error", "errors", "err_log", etc.

---

## Comparison Operators in Splunk

Valid comparison operators: `=`, `!=`, `<`, `>`, `<=`, `>=`. The operator `?=` is not a valid Splunk comparison operator. This is tested directly.

---

## The `fillnull` Command

Replaces null values in fields with a specified value. If the value argument is not specified, `fillnull` replaces null values with 0 by default. This is the exam-tested default behavior.

```splunk
index=web_logs
| fillnull value="N/A"
```

Replaces all null fields in all events with the string "N/A".

```splunk
index=web_logs
| fillnull value=0 response_bytes
```

Replaces nulls in only the `response_bytes` field with 0. Without specifying a field name, `fillnull` applies to all fields — which is the default behavior when no field is named.

```splunk
index=web_logs
| stats sum(bytes) AS total_bytes by host
| fillnull value=0 total_bytes
```

Useful after `stats` to replace null values in computed fields for hosts that had no matching events.

---

## The `table` Command

Selects which fields to display and in what order. Does not filter events — only changes the columns shown.

```splunk
index=web_logs
| table _time, src_ip, uri, status, response_bytes
```

Expected output — only the named fields are shown, in the order listed:

|_time|src_ip|uri|status|response_bytes|
|---|---|---|---|---|
|2024-01-01 10:00:01|10.0.0.5|/index.html|200|4521|

---

## The `rename` Command

```splunk
index=web_logs
| rename src_ip AS "Source IP", status AS "HTTP Status"
```

Use quotes for display names that contain spaces. After renaming, the original field name is no longer accessible in subsequent pipeline commands.

---

## The `fields` Command

```splunk
index=web_logs
| fields src_ip, uri, status
```

Keeps only the listed fields, removes all others. Equivalent to `fields + src_ip, uri, status`.

```splunk
index=web_logs
| fields - _raw, _indextime
```

Removes the listed fields, keeps all others. The `-` form is used to exclude fields.

`fields +` keeps only listed fields. `fields -` removes listed fields. Removing fields early in the pipeline improves search performance significantly on large datasets by reducing data transferred from indexers.

---

## The `dedup` Command

Removes duplicate events based on one or more fields. By default, keeps the first occurrence of each unique value combination.

```splunk
index=web_logs
| dedup src_ip
```

Returns one event per unique `src_ip` value — the first one seen in the result set.

```splunk
index=web_logs
| dedup src_ip, uri
```

Returns one event per unique `src_ip` + `uri` combination.

```splunk
index=web_logs
| dedup src_ip sortby -_time
```

The `sortby` option within `dedup` controls which event is kept — here, the most recent event per `src_ip` is kept.

---

## The `sort` Command

```splunk
index=web_logs
| stats count by src_ip
| sort -count
```

`-` prefix means descending. `+` or no prefix means ascending (default).

```splunk
index=web_logs
| sort +_time
| head 20
```

```splunk
index=web_logs
| sort limit=100 -response_bytes, +uri
```

Sort up to 100 results by `response_bytes` descending, then by `uri` ascending as a tiebreaker. The `limit` option controls how many results the sort considers.

---

# Domain 3 Correlating Events

## The `transaction` Command

Groups related events into a single transaction based on shared field values and/or time constraints. The `transaction` command creates a single event from a group of events — it merges multiple related events into one combined "super-event." This is its core purpose. It is distinct from `stats` (which aggregates values without preserving individual events) or `join` (which merges datasets on shared fields).

```splunk
index=web_logs
| transaction session_id
```

Groups all events sharing the same `session_id` into one transaction event.

```splunk
index=web_logs
| transaction session_id maxspan=30m maxpause=5m
```

`maxspan=30m` means the total duration from first to last event in the transaction cannot exceed 30 minutes. `maxpause=5m` means no two consecutive events within the transaction may be more than 5 minutes apart.

```splunk
index=auth_logs
| transaction src_ip maxevents=20 startswith="login attempt" endswith="login success"
```

Groups events by `src_ip` where a transaction starts at an event matching "login attempt" and ends at "login success", with a maximum of 20 events per transaction.

```splunk
sourcetype=access_combined
| transaction JSESSIONID
```

After this command, each result event contains:

- `duration` — time from first to last event in the transaction (in seconds)
- `eventcount` — number of events grouped into this transaction
- `_raw` — combined raw text of all grouped events

The field `maxspan` is not automatically added as a result field — it is only a command argument. This is tested: `maxspan` is NOT created as a field, but `duration` and `eventcount` ARE.

Key transaction options:

|Option|Description|
|---|---|
|`maxspan=<time>`|Maximum total duration — the maximum time between the earliest and latest events in a transaction. Events outside this window start a new transaction.|
|`maxpause=<time>`|Maximum gap allowed between any two consecutive events in the transaction|
|`maxevents=<N>`|Maximum number of events per transaction (default 1000)|
|`startswith=<filter>`|Event matching this filter starts a new transaction|
|`endswith=<filter>`|Event matching this filter closes the current transaction|
|`keepevicted=true`|Keep transactions that did not meet the end condition|

The `transaction` command is most appropriate when event grouping is based on start/end values (login/logout, request/response, purchase/confirmation). Use `stats` when you only need aggregate counts or values — `stats` is far faster and more scalable.

There is a 1000 event limitation per transaction group by default (configurable via `maxevents`). This is a critical deciding factor when choosing between `transaction` and `stats` on large datasets — if a transaction might contain more than 1000 events, the results will be truncated.

All events in a transaction must be related by one or more fields. They do not need to have the same timestamp, the same sourcetype, or the exact same set of fields.

The `transaction` command is not the most efficient command for grouping events in large environments — `stats` is. The `transaction` command is resource-intensive, consuming more CPU and memory, particularly in distributed deployments where events must be gathered from multiple indexers before grouping can occur.

### Transaction vs stats — Decision Guide

|Use `transaction` when|Use `stats` when|
|---|---|
|You need to see the raw events within each group|You only need aggregate counts/sums/averages|
|Event grouping uses start/end conditions|Grouping is by field values only|
|You need `duration` or `eventcount` per group|Performance is critical|
|Groups may span multiple sourcetypes|Dataset is large (over thousands of groups)|
|You need to analyze the _raw text of grouped events|You can derive what you need from field aggregation|

---

## Reporting on Transactions

After `transaction` groups events, pipe the results into `stats` to produce summary reports. The `duration` and `eventcount` fields added by `transaction` are available for aggregation with `stats` just like any other field.

```splunk
index=web_logs
| transaction sessionid maxspan=30m
| stats count as total_sessions avg(duration) as avg_session_duration max(eventcount) as max_events_per_session by host
```

Groups sessions by host and summarizes count, average duration, and peak event count per session.

```splunk
index=auth_logs
| transaction user startswith="action=login" endswith="action=logout"
| where duration > 3600
| stats count as long_sessions by user
| sort -long_sessions
```

Finds users with sessions longer than one hour. `where duration > 3600` filters individual transactions after grouping; `stats` then summarizes across the filtered set.

```splunk
index=web_logs
| transaction sessionid
| stats count as total_transactions avg(duration) as avg_duration sum(eventcount) as total_events
```

Produces a single-row global summary across all transactions.

Key rules for reporting on transactions:

- `duration` and `eventcount` are always available after `transaction` — use them in `stats` freely
- `where` can filter individual transactions before `stats` aggregates them
- `stats` after `transaction` collapses all transaction rows into a summary table — raw grouped events are no longer accessible after `stats` runs
- This pattern is slower than pure `stats` — use only when `startswith`/`endswith` grouping logic is required or when filtering on `duration`/`eventcount`

---

## Searching Within Transactions

To identify all contributing events within a transaction that contains at least one REJECT event:

```splunk
index=main | transaction sessionid | search REJECT
```

This is the correct approach. The `transaction` command first groups events by `sessionid` into logical units. Then `search REJECT` filters those grouped transactions, keeping only those where at least one event contains the word REJECT — and returns all events within matching transactions, including non-REJECT events that belong to the same group.

The alternative `index=main REJECT | transaction sessionid` is incorrect because it first filters to only REJECT events before forming transactions, so non-REJECT events in the same transaction would be excluded entirely. The order of operations matters.

To understand what the search `sourcetype=cisco_esa | transaction mid, dcid, icid | timechart avg(duration)` returns: it shows the average time elapsed during each transaction for all transactions — specifically the mean of the `duration` field across all formed transactions, plotted over time.

---

## Subsearches for Correlation

A subsearch runs first and passes its results as a filter to the outer search. Enclosed in square brackets `[ ]`. The subsearch completes first and its results become part of the main search criteria.

```splunk
index=web_logs
    [search index=threat_intel
     | fields src_ip
     | rename src_ip AS src_ip]
```

This returns web log events where the `src_ip` matches any IP in the threat intelligence index.

```splunk
index=auth_logs action=failure
    [search index=auth_logs action=failure
     | stats count by src_ip
     | where count > 10
     | fields src_ip]
| stats count by src_ip, user
```

This finds IPs that failed authentication more than 10 times, then looks at all failed auth events from those specific IPs grouped by user.

Subsearches return a maximum of 10,000 results by default and have a 60 second timeout by default. Use `append`, `join`, or `lookup` for large correlation tasks that would exceed these limits.

---

## The `append` Command

Appends results of a subsearch to the current results set as additional rows.

```splunk
index=web_logs status=200
| stats count AS success_count by host
| append
    [search index=web_logs status>=400
     | stats count AS error_count by host]
```

---

## The `join` Command

Joins results of a subsearch with the current results on a shared field — similar to SQL JOIN. `join` can be slow on large datasets and is generally a last resort for correlation tasks.

```splunk
index=web_logs
| stats count by src_ip
| join src_ip
    [search index=asset_db
     | table src_ip, owner, department]
```

join types:

- `join type=inner` — only matching records (default)
- `join type=left` — all records from main search, with matched values from subsearch where available
- `join type=outer` — all records from both, null-filled where no match

---

# Domain 4 Creating and Managing Fields

## Field Extraction Overview

Field extractions allow you to pull structured data out of unstructured raw event text. Splunk supports two main methods:

- Regex — for complex or irregular log formats where fields are not consistently delimited
- Delimiter — for structured logs with consistent separators

Delimiter-based field extraction works on log files that use consistent separators like CSV (commas), pipe-separated, tab-separated, or space-separated formats. XML and JSON have dedicated sourcetypes that handle their own parsing.

Fields extracted using the Field Extractor (FX) persist as knowledge objects — they are saved to `props.conf` and `transforms.conf` and applied automatically in future searches. They do not need to be redefined for each search.

---

## Using the Field Extractor (FX) — Interactive

The Field Extractor (FX) is used to extract a custom field and save it as a persistent knowledge object.

How to open the Field Extractor:

1. Run a search and return events
2. Click on an event to expand it
3. Click Event Actions → Extract Fields — this option automatically identifies the data type, sourcetype, and sample event for you
4. Choose Regular Expression or Delimiter
5. Highlight the value you want to extract — Splunk auto-generates the regex
6. Name the field and save

The option Event Actions → Extract Fields is the one that automatically identifies data type, sourcetype, and sample event. The other paths (Fields sidebar → Extract New Fields, Settings → Field Extractions → New Field Extraction) require manual specification and do not auto-identify these properties. This distinction is directly tested.

---

## Field Extractor Delimiters

The Field Extractor can detect the following delimiters: Tabs, Pipes, Spaces, Commas (and colons). It is not limited to any predefined delimiter set — it uses pattern recognition and heuristics to identify recurring separators in the data.

The FX supports:

- Tab-separated values (TSV) — common in system logs
- Pipe-separated values — common in middleware logs
- Comma-separated values (CSV) — common in exported data files
- Space-separated values — common in Apache/NGINX access logs
- Colon-separated values — common in key:value formatted logs

---

## Delimiter Field Extraction — Step by Step

Used when raw events have values separated by a consistent character. No regex is written — Splunk splits the event into columns automatically and you name each column.

Example raw event:

```
2024-01-15,john,login,192.168.1.10,success
```

How to perform a delimiter extraction using the FX:

1. Run a search that returns events of the relevant sourcetype
2. Click on an event to expand it
3. Click Event Actions → Extract Fields
4. Select Delimiter (not Regular Expression)
5. Splunk detects the delimiter automatically — confirm or select manually (comma in this example)
6. Splunk splits the event into numbered columns — assign a field name to each column you want to keep:

|Column|Raw Value|Field Name|
|---|---|---|
|Column 1|2024-01-15|date|
|Column 2|john|user|
|Column 3|login|action|
|Column 4|192.168.1.10|src_ip|
|Column 5|success|status|

7. Preview the extraction against sample events to confirm correct splitting
8. Save — persists as a knowledge object in `props.conf` and `transforms.conf`

After saving, every future search against that sourcetype automatically has `user`, `action`, `src_ip`, and `status` as extracted fields.

Key exam facts for delimiter extraction:

- Use delimiter FX when fields are separated by a consistent single character (comma, pipe, tab, space, colon)
- Use regex FX when the log format is irregular or fields need pattern matching
- Both delimiter and regex extractions persist identically — saved to `props.conf` and `transforms.conf`, scoped to a sourcetype
- After manually editing the saved extraction in `transforms.conf`, the FX UI can no longer edit it — applies to both regex and delimiter extractions
- Columns you do not name are ignored — you do not need to name every column
- The FX auto-detects the delimiter from sample events but you can override it manually

| File                | Contains                                       | Think of it as        |
| ------------------- | ---------------------------------------------- | --------------------- |
| **props.conf**      | All log sources (sourcetypes) + links to rules | **Directory / Index** |
| **transforms.conf** | The actual regex rules as reusable definitions | **Library of rules**  |

---

## Field Extractor — Manual Regex Editing

After you manually edit a regular expression that was created by the FX UI, it is no longer possible to edit the field extraction in the Field Extractor UI. Manual edits bypass the FX UI's intended workflow. The UI loses track of the custom regex and can no longer reliably display or modify the extraction. Future edits must be made directly in `transforms.conf` and `props.conf`. The FX does not maintain a separate version alongside the manually edited one.

---

## The `require` Option in FX Regex Extractions

When performing a regex field extraction using the FX and the require option is used, only events with the required string will be included in the extraction. It acts as a pre-filter: the extraction regex is only applied to events that already contain the specified string or pattern. Events without the required string still appear in search results — they simply will not have the extracted field. The regex itself can still be edited after saving. The required string does not globally enforce the field's existence in all future events — it only controls which events the extraction regex is applied to during this specific extraction definition.

---

## The `rex` Command — Inline Regex Extraction

`rex` extracts fields inline using a named capture group. Does not persist — only applies to the current search. The named capture group syntax is `(?P<fieldname>pattern)`.

```splunk
index=web_logs
| rex field=_raw "user=(?P<username>\w+)"
```

Creates a new field `username` containing the word-character sequence after "user=".

```splunk
index=web_logs
| rex field=uri "\/(?P<section>[^\/]+)\/"
```

Extracts the first URL section (e.g., from "/products/shoes/123" this extracts "products").

```splunk
index=syslog
| rex field=_raw "(?P<process_name>[A-Za-z_]+)\[(?P<pid>\d+)\]"
```

Extracts both process name and PID from syslog-style events like "sshd[1234]".

```splunk
index=web_logs
| rex field=_raw "(?P<src_ip>\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})"
| stats count by src_ip
```

Extracts the first IP address pattern found in raw events.

---

## The `rex` Command — Mode Sed

`rex mode=sed` performs find-and-replace on a field using sed-like syntax. Useful for masking sensitive data or normalizing values.

```splunk
index=web_logs
| rex mode=sed field=uri "s/\/v[0-9]+\//\/api\//"
```

Replaces version strings like "/v1/" or "/v12/" with "/api/" in the URI field.

```splunk
index=auth_logs
| rex mode=sed field=_raw "s/password=[^\s]*/password=REDACTED/g"
```

Masks all password values in raw events — the `g` flag replaces all occurrences, not just the first.

---

## Persistent Field Extractions via `transforms.conf` and `props.conf`

To make a field extraction persist across searches, it must be saved to configuration files.

`props.conf` defines where the extraction applies:

```ini
[sourcetype::apache_access]
EXTRACT-http_method = ^(?P<http_method>\w+)\s
```

`transforms.conf` used for more complex extractions with `REPORT-`:

```ini
[extract_http_fields]
REGEX = (?P<http_method>\w+)\s(?P<uri>\S+)\s(?P<http_version>HTTP/[\d\.]+)
```

```ini
[sourcetype::apache_access]
REPORT-http_fields = extract_http_fields
```

The `EXTRACT-` stanza directly embeds the regex. The `REPORT-` stanza references a named transform in `transforms.conf`, which allows the same transform to be reused across multiple sourcetypes.

---

## If a Shared Report Returns No Results

If a user shares a report built on a custom field extraction and another user runs it with no results returned, the likely causes are:

- The extraction is private — field extractions saved as private are only accessible to their creator. Other users cannot use the extraction definition, so the field never gets populated for them.
- The person does not have access to the index — Splunk's role-based access control filters out data from indexes the user is not permitted to search, resulting in no events and therefore no results.

Fast mode being enabled or the dashboard being private are not the primary causes of a report returning empty results when the extraction itself is the issue.

---

# Domain 5 Creating Field Aliases and Calculated Fields



## Field Aliases

A field alias gives an alternate name to an existing field. The original field still exists — both the original name and the alias are accessible. Field aliases are useful for normalizing field names across different sourcetypes so that searches do not need to know which specific field name a sourcetype uses.

Field aliases do not replace the original field name — both names remain accessible. This is a key distinction tested on the exam: the alias adds an alternate name, it does not rename or remove the original.

Field aliases can be used in lookup file definitions. This is one of their most practical applications. If your events use `emp_no` but your lookup table uses `employee_id`, you can alias `emp_no` to `employee_id` and reference the alias in the lookup definition. The lookup will then work correctly across any sourcetype that has the alias defined.

Field aliases apply at search time, not index time. They do not require re-indexing.

Creating a Field Alias in the UI:

1. Settings → Fields → Field Aliases → New Field Alias
2. Select the App and the Sourcetype (or source or host)
3. Enter: Existing field name → Alias name
4. Save

Example: Alias `src` to `src_ip` for a sourcetype that uses `src`:

```
Sourcetype: firewall_logs
src → src_ip
```

After this alias is created, searches can reference either `src` or `src_ip` on events from `firewall_logs` sourcetype. Lookups that expect `src_ip` will also work against this data.

---

## Calculated Fields

A calculated field uses an `eval` expression to derive a new field. It is saved as a knowledge object and applied automatically at search time for a given sourcetype. Calculated fields are shortcuts for performing calculations using the `eval` command — they allow you to define eval logic once and have it applied automatically, without writing it in every search.

Calculated fields:

- Can be used in the search bar directly, just like extracted or default fields
- Can be based on extracted fields — the base field must already exist in the data for the calculation to work
- Are shortcuts for performing calculations using the `eval` command
- Can be applied to any sourcetype or source, not only `host` and `sourcetype` — the restriction to only host and sourcetype is false

A calculated field cannot be based on tags, output fields from a lookup directly, or fields generated from a search string in isolation — the extracted field is the immediate required foundation. If the base field does not exist in the raw event, the calculated field will not produce a value.

Creating a Calculated Field in the UI:

1. Settings → Fields → Calculated Fields → New Calculated Field
2. Select App and Sourcetype
3. Name the field
4. Write the eval expression

Example: Create `response_kb` from `response_bytes`:

```
Name: response_kb
Eval Expression: response_bytes / 1024
```

Every event from that sourcetype that has `response_bytes` will automatically have `response_kb` added at search time.

Example: Create a severity label:

```
Name: severity_label
Eval Expression: if(severity >= 8, "Critical", if(severity >= 5, "High", "Low"))
```

Example: Normalize a duration field:

```
Name: duration_display
Eval Expression: tostring(duration, "duration")
```

---

## Knowledge Object Application Order

The order in which Splunk applies knowledge objects at search time is:

1. Field Extractions — fields are parsed from raw event data first
2. Field Aliases — alternate names are applied to extracted fields
3. Lookups — lookup enrichment uses the extracted and aliased fields to match against external tables

This order matters because each step depends on the previous one. Aliases must follow extractions (you can only alias a field that has been extracted). Lookups must follow aliases (the lookup's input field may be an alias, and that alias must be resolved before the lookup can match). Getting this order wrong is a common exam distractor.

---

# Domain 6 Creating Tags and Event Types

## Tags

Tags let you assign meaningful labels to specific field-value pairs. A tag applies across all sourcetypes where that field-value exists. Tags are based on field/value pairs and are designed to make data more understandable by providing human-readable labels that abstract away from raw field values.

Tags are case-sensitive. A tag named `Error` is distinct from a tag named `error`. Tags do not categorize events based on a search (that is what event types do) — tags are attached to specific field-value pairs.

Creating a Tag in the UI:

1. Run a search and find an event with the desired field-value pair
2. Click the field value → Edit Tags
3. Type the tag name and save

Or via Settings → Tags → New Tag

Searching with tags:

```splunk
tag=failed-login
```

```splunk
index=windows_logs tag=failed-login
| stats count by Account_Name
```

To limit a tag search to a specific field, use the `tag::<fieldname>=<tagvalue>` syntax:

```splunk
tag::host=alert
```

This returns events where the `host` field has been tagged with "alert" — different from `tag=alert` which matches the tag on any field.

To return events containing a tag named `Privileged`, the correct search is `tag=Priv*`. The wildcard `*` matches any tag beginning with "Priv", including "Privileged". The search `tag=Priv` (without wildcard) matches only events tagged with the exact string "Priv" — this is a common exam question testing exact vs wildcard matching.

Tags create a multi-value field called `tag` automatically on matching events. You can search this field directly or use the `tag::field=value` syntax.

---

## Event Types

An event type is a saved search that categorizes events. When an event matches the search criteria, it gets assigned the event type name as a field value. Event types categorize events based on a search and can be tagged.

Event types do not require a time range — the search query is what defines the event type. Time ranges are specified at search execution time, not in the event type definition. Event types are useful when the search string needs to be reused in future searches across many different contexts.

Valid ways to create an event type:

- Via the Settings menu: Settings → Event Types → New
- By selecting an event in search results and clicking Event Actions → Build Event Type

The `searchtypes` command does not exist. Editing the `event_type` stanza in `props.conf` is not a valid creation path for event types.

Creating an Event Type in the UI:

1. Run a search that returns the events you want to categorize
2. Click Save As → Event Type
3. Name it and optionally set a priority (1-10, lower number = higher priority) and a color
4. Save

Searching with event types:

```splunk
eventtype=brute_force_attempt
```

```splunk
eventtype=brute_force_attempt
| stats count by src_ip
```

Event Type vs Saved Search:

- Event type tags matching events with a field at search time. No scheduling. Best when the search string needs to be reused across many different searches, dashboards, or reports — and when formatting (color) needs to be included with the search string, which is a scenario where event types are more effective than saved searches.
- Saved search stores a search query for reuse. Can be scheduled and alert-enabled. Better for dashboard integration or notification workflows. Does not tag events or add color formatting.

When multiple event types with different color values are assigned to the same event, priority determines which color is displayed. The event type with the highest priority — the lowest priority number, e.g., 1 beats 10 — takes precedence. Priority is configured in `eventtypes.conf` and in the UI when saving the event type. Rank, weight, and precedence are not the determining factors — only priority.

Splunk alerts can be based on searches that run in real-time or on a regular schedule. An alert condition of "no matching events" is not a base search behavior — alerts trigger based on scheduled or real-time search results.

---

# Domain 7 Creating and Using Macros

## What is a Macro?

A macro is a reusable SPL snippet saved as a knowledge object. It can be called inside any search using backtick syntax. Macros can accept arguments. A macro is a reusable search string that may have a flexible time range — it is not required to contain a full search, have a fixed time range, or contain only a portion of a search. Time ranges can be parameterized via arguments or left to be defined at execution time by the calling search.

Macros can contain any valid SPL — from a single eval expression to an entire multi-stage pipeline. They reduce duplication and make complex searches maintainable.

---

## Creating a Macro in the UI

1. Settings → Advanced Search → Search Macros → New Search Macro
2. Name it (no spaces — use underscores; no argument count suffix if it takes no arguments)
3. Write the SPL definition
4. Optionally add arguments, a validation expression, and a validation error message
5. Save

---

## Basic Macro (No Arguments)

Definition:

```
Name: failed_logins
Definition: index=windows_logs EventCode=4625
```

Usage:

```splunk
`failed_logins`
| stats count by Account_Name
```

The backtick syntax `` `macroname` `` is the only way to call a macro in a search. Double quotes or single quotes do not expand macros.

---

## Macro with Arguments

Arguments are defined when the macro is created — their names and count are fixed at creation time. Argument values are provided at execution time — they are substituted into the search string when the macro is called. This is the key distinction: structure is defined at creation, values are resolved at execution.

Arguments are referenced in the definition using `$argname$` syntax. The macro name must include the argument count in parentheses at the end of the name. To accept one argument the name ends with `(1)`, for two arguments `(2)`, for three `(3)`, and so on.

Definition:

```
Name: failed_logins_by_user(1)
Arguments: username
Definition: index=windows_logs EventCode=4625 Account_Name="$username$"
```

Usage:

```splunk
`failed_logins_by_user(administrator)`
| stats count by src_ip
```

Multi-argument macro:

```
Name: index_search(2)
Arguments: idx, sourcetype_val
Definition: index=$idx$ sourcetype=$sourcetype_val$
```

```splunk
`index_search(windows_logs, WinEventLog)`
| table _time, host, EventCode
```

---

## Macro Naming Convention

When configuring a macro that takes two arguments (e.g., `action` and `JSESSIONID`), the correct macro name is `sessiontracker(2)` and the arguments field contains `action, JSESSIONID` — without dollar signs. Dollar signs appear only in the definition body (e.g., `action=$action$`), not in the Arguments configuration field.

When calling a macro with arguments in a search string, pass values directly inside the parentheses: `` `convert_sales(euro, €, .79)` `` — no dollar signs in the call syntax.

For the `convert_sales(3)` macro where the definition uses `$currency$`, `$symbol$`, and `$rate$`, the correct call syntax is:

```splunk
`convert_sales(euro, €, .79)`
```

---

## Calling a Macro in a Search

A pipe may always follow a macro. Because macros expand to SPL, a pipe after a macro is syntactically identical to a pipe after any SPL statement. Ownership of the macro, the app it is defined in, and sharing settings (global vs app vs private) affect whether you can access and use the macro — but they do not affect the syntax of chaining it with a pipe once you can access it.

Valid macro usage — macro as a standalone search component with pipe after it:

```splunk
index=main source=mySource oldField=* | `makeMyField(oldField)` | table _time newField
```

Valid macro usage — macro inside an eval expression:

```splunk
index=main source=mySource oldField=* | eval newField=`makeMyField(oldField)` | table _time newField
```

Invalid — macro inside stats `if()` as a boolean condition:

```splunk
index=main | stats if(`makeMyField(oldField)`)
```

This is invalid because `stats if()` expects a boolean expression, not a macro that returns a field value.

Invalid — macro wrapped in double quotes:

```splunk
index=main | "`makeMyField(oldField)`"
```

This treats the entire string as a literal search term and does not expand the macro.

---

## Macro Validation

When creating a macro with arguments, you can add:

- Validation Expression — an eval expression that must return true for the macro to run (e.g., `isnum($rate$)`)
- Validation Error Message — shown to the user if validation fails

---

# Domain 8 Creating and Using Workflow Actions

## What is a Workflow Action?

A workflow action adds a custom link or action to the event actions menu — the dropdown that appears when you click on an event field in search results. It allows analysts to pivot from a search result directly into an external tool, another Splunk search, or a data submission.

Workflow actions can be:

- GET — open a URL in the browser (retrieves a resource)
- POST — submit form data to an external URL
- Search — launch a new Splunk search pre-populated with field values from the event

---

## Creating a Workflow Action in the UI

1. Settings → Fields → Workflow Actions → New Workflow Action
2. Name it
3. Set Apply to: Sourcetype, Event type, or All events
4. Choose type: GET, POST, or Search
5. Configure the action
6. Save

The workflow actions that can be executed from search results are GET, POST, and Search. "LOOKUP" is not a workflow action type.

---

## GET Workflow Action

Opens an external URL in the browser. Field values can be inserted into the URL using `$field_name$` syntax. When the action type is set to "link," the workflow action method used is GET — because clicking a hyperlink sends an HTTP GET request to retrieve the target resource.

GET workflow actions can be configured to open the URL link in the current window or in a new window — this is directly tested.

GET workflow actions do not need to be configured with POST arguments. Configuration of GET workflow actions does not include choosing a sourcetype — that is set at the workflow action level, not the GET configuration level. Label names for GET workflow actions do not require dollar signs around field names — dollar signs are used in the URI parameter, not the label.

Information needed to create a GET workflow action:

- A name for the workflow action (used internally by Splunk to identify it)
- A URI where the user will be directed at search time
- A label that will appear in the Event Action menu at search time

You do not need to provide "a name for the URI" as a separate item — the URI itself is the endpoint.

Example — open VirusTotal lookup for a `src_ip` field:

```
Name: VirusTotal IP Lookup
Apply to: All events
Show action in: Both event menu and fields
Type: GET
URI: https://www.virustotal.com/gui/ip-address/$src_ip$
Label: Look up $src_ip$ on VirusTotal
Open in: New window
```

When a user clicks this action on an event containing `src_ip=10.0.0.5`, the browser opens `https://www.virustotal.com/gui/ip-address/10.0.0.5`.

---

## POST Workflow Action

Submits form data via HTTP POST to an external URL. POST workflow actions can be configured to send POST arguments to the URI location. The visibility of POST workflow actions (whether shown in the event menu or field menu) is controlled through configuration — they are not shown in both menus by default.

POST workflow actions are not designed to send email directly (that is an alert action). Configuration of POST workflow actions does not include choosing a sourcetype as part of the POST-specific setup.

Example — open a ticket:

```
Type: POST
URI: https://tickets.internal/api/create
Post Arguments:
  ip = $src_ip$
  description = Suspicious activity detected from $src_ip$
  severity = $severity$
```

---

## Search Workflow Action

Launches a new Splunk search pre-populated with values from the event. The Search workflow action uses field values to perform a secondary search. This is what distinguishes it from GET (opens a URL) and POST (submits data externally).

The user can define the time range of the search when creating the workflow action. Search workflow actions are not real-time searches by default. Search workflow actions cannot be configured as scheduled searches — their execution is tied to user interaction. Search workflow actions can use the `transaction` command in their search string — there is no restriction preventing this.

The required field when creating a Search workflow action is the search string — without it, the action has no instruction for what to execute.

Searches generated by workflow actions run with the same permissions as the user running them. This is a critical security consideration: workflow actions inherit the triggering user's data access level. A user with limited access who triggers a workflow action will only see data they are permitted to access. Workflow actions can use macros, are not limited to 256 characters, and can run in different apps than the one where the workflow was defined.

Example — pivot on src_ip:

```
Type: Search
Search string: index=* src_ip=$src_ip$ earliest=-24h
Open in: New window
```

---

# Domain 9 Creating Data Models

## What is a Data Model?

A data model is a hierarchical structure of datasets built on top of Splunk searches. It provides a structured, consistent schema for pivot-based reporting and is the foundation for Pivot and CIM normalization.

CIM = standard schema applied using multiple knowledge objects (extractions, aliases, lookups, tags, event types) + data models

- Field extraction → gets data
- Lookup → enriches/normalizes
- CIM → **organizes everything into a standard structure**

Data models are composed of one or more of these dataset types:

- Events datasets — the foundational layer; raw, timestamped event records filtered by a search constraint
- Search datasets — based on saved searches that filter or transform events using SPL
- Transaction datasets — groups of related events assembled using the transaction command

Any child of an event, transaction, or search dataset is also a valid dataset — but "any child" is not itself a distinct primary type; the three primary types are events, searches, and transactions. 

The relationship between data models and pivots: data models provide the datasets for pivots. Pivots rely on the structured, schema-defined data in a data model to offer drag-and-drop analysis. You cannot pivot on raw unstructured data directly. Pivots and data models are not the same thing, and pivots do not provide datasets to data models — the direction is always data model → pivot.

Pivot is used for creating reports and dashboards — not for creating datasets. End users (business analysts) are the group that most commonly uses pivots. Knowledge Managers and architects design and maintain the underlying data models, but the day-to-day drag-and-drop exploration is done by end users who do not need to write SPL.

---

## Data Model Structure

```
Data Model
└── Root Dataset (search-based or transaction-based)
    ├── Attributes (fields)
    └── Child Dataset (inherits parent constraint + adds its own)
        ├── Attributes
        └── Child Dataset
            └── Attributes
```

Each dataset in a data model is based on a search constraint. Child datasets inherit the parent's constraint and add their own filter on top. The two parts of a root event dataset are constraints and fields. Constraints define which events are included (the equivalent of a WHERE clause); fields define what attributes are extracted and available for analysis in Pivot.

---

## Creating a Data Model in the UI

1. Settings → Data Models → New Data Model
2. Name it and select the App
3. Add a Root Dataset:
    - Root Event — based on a search constraint (most common)
    - Root Transaction — based on `transaction` command
    - Root Search — based on any SPL (most flexible)
4. Add attributes (fields) manually or auto-extract from sample events
5. Add child datasets for sub-categorization
6. Save

---

## Root Dataset Example

Root dataset for web traffic:

```
Root Event Name: Web_Access
Constraint: index=web_logs sourcetype=access_combined
```

Attributes added:

|Field|Type|
|---|---|
|`src_ip`|String|
|`uri`|String|
|`status`|Number|
|`response_bytes`|Number|
|`http_method`|String|

Child dataset for errors:

```
Name: Web_Errors
Additional Constraint: status >= 400
```

Web_Errors inherits the constraint `index=web_logs sourcetype=access_combined` from the parent and adds `status >= 400`. An event must satisfy both constraints to appear in Web_Errors.

---

## Auto-Extracted Fields in Data Models

Data model fields can be added using the Auto-Extracted method. Auto-Extracted fields:

- Can have their data type changed
- Can be given a friendly name for use in Pivot
- Can be hidden in Pivot
- Can be added even if they already exist in the dataset's constraint definition

---

## Data Model Acceleration

Accelerating a data model pre-computes summaries (tsidx files) so pivot reports and `tstats` queries run much faster on large datasets.

Facts about data model acceleration:

- Accelerated data models cannot be edited — you must disable acceleration, make changes, then re-enable acceleration to rebuild the summaries
- Private data models cannot be accelerated — you must share a data model (make it global or app-level) before accelerating it
- You must have administrative permissions or the `accelerate_datamodel` capability to accelerate a data model
- Root events can be accelerated — in fact, acceleration often starts at the root level to maximize the benefit for all child datasets

By default, data model acceleration in the Splunk CIM add-on is turned off. Administrators must explicitly enable it. This is tested: CIM acceleration defaults to off, not on.

Acceleration requires additional disk space and CPU during summary building. Only accelerate data models that are used frequently and on large datasets where the performance benefit outweighs the resource cost.

---

## The `datamodel` Command

The correct way to use the `datamodel` command to search fields in the Web data model within the Web dataset:

```splunk
| datamodel Web Web search | fields Web*
```

The syntax is: `| datamodel <DataModelName> <DatasetName> search`. The first argument is the data model name, the second is the dataset name within that model.

For the search string `| datamodel Application_State All_Application_State search`, events will be returned from the data model named Application_State. "All_Application_State" is the dataset name within that model, not the model name itself. The pipe before `datamodel` is correct — it is a generating command that initiates the pipeline.

```splunk
| datamodel Authentication Successful_Authentication search
| stats count by Authentication.user
| sort -count
```

Field names returned by the `datamodel` command are prefixed with the dataset name. Use `fields Authentication.*` or reference them explicitly with the prefix.

---

## Using Pivot with a Data Model

1. Go to Pivot (via the app or Settings → Data Models → Pivot)
2. Select a data model and dataset
3. Drag and drop fields to build charts, tables, and maps
4. Save as a report or dashboard panel

Pivot generates the underlying SPL automatically — the user never needs to write SPL to use Pivot. This is why end users, not power users or admins, are the primary Pivot audience.


## Examples for Data Model:
#### 1. Event Dataset — Authentication Data Model

```
Authentication  (Root Event Dataset)
├── Fields:
│     ├── _time
│     ├── user
│     ├── src_ip
│     ├── dest_ip
│     ├── action
│     ├── app
│     ├── host
│     └── tag
│
├── Constraint:
│     tag=authentication
│
└── Child Datasets:
      ├── Successful_Authentication
      │     ├── Constraint: action=success
      │     ├── Fields inherited from parent
      │     └── Extra field: reason=success
      │
      └── Failed_Authentication
            ├── Constraint: action=failure
            ├── Fields inherited from parent
            └── Extra field: reason=failure
```
#### 2. Search Dataset — Network Bandwidth Summary

```
Bandwidth_Summary  (Root Search Dataset)
├── Fields:
│     ├── src_ip
│     ├── total_bytes
│     ├── total_bytes_in
│     ├── total_bytes_out
│     ├── connection_count
│     └── location
│
├── Base Search:
│     index=network
│     | stats sum(bytes_in) as total_bytes_in
│             sum(bytes_out) as total_bytes_out
│             sum(bytes) as total_bytes
│             count as connection_count
│             by src_ip, location
│
└── Child Datasets:
      ├── High_Bandwidth_Users
      │     ├── Constraint: total_bytes > 1000000
      │     └── Fields inherited from parent
      │
      └── Low_Bandwidth_Users
            ├── Constraint: total_bytes < 100000
            └── Fields inherited from parent
```

#### 3. Transaction Dataset — User Session Tracking

```
User_Sessions  (Root Transaction Dataset)
├── Fields:
│     ├── user
│     ├── src_ip
│     ├── duration
│     ├── eventcount
│     ├── starttime
│     ├── endtime
│     ├── action
│     └── department
│
├── Transaction Definition:
│     index=security
│     | transaction user
│         startswith="action=login"
│         endswith="action=logout"
│         maxspan=8h
│         maxpause=1h
│
└── Child Datasets:
      ├── Long_Sessions
      │     ├── Constraint: duration > 3600
      │     ├── Fields inherited from parent
      │     └── Extra field: risk=high
      │
      ├── Short_Sessions
      │     ├── Constraint: duration < 300
      │     ├── Fields inherited from parent
      │     └── Extra field: risk=low
      │
      └── Incomplete_Sessions
            ├── Constraint: eventcount < 2
            ├── Fields inherited from parent
            └── Extra field: risk=investigate
```

#### Side by Side Summary

```
Authentication          Bandwidth_Summary        User_Sessions
(Event Dataset)         (Search Dataset)         (Transaction Dataset)
───────────────         ─────────────────        ─────────────────────
Constraint:             Base Search:             Transaction Definition:
tag=authentication      stats sum(bytes)         transaction user
                        by src_ip                startswith=login
                                                 endswith=logout

Each row =              Each row =               Each row =
one raw event           one calculated result    one complete session

Child: Successful       Child: High_Bandwidth    Child: Long_Sessions
Child: Failed           Child: Low_Bandwidth     Child: Short_Sessions
                                                 Child: Incomplete
```

---

## `tstats` Command — Fast Queries on Accelerated Data Models

`tstats` queries tsidx summary files from accelerated data models and is extremely fast compared to `stats` because it does not need to read raw event data.

```splunk
| tstats count FROM datamodel=Web.Web_Access BY Web_Access.src_ip
```

```splunk
| tstats sum(Web_Access.response_bytes) AS total_bytes
  FROM datamodel=Web.Web_Access
  WHERE Web_Access.status >= 400
  BY Web_Access.src_ip
  SPAN=1h
```

Field names in `tstats` must be prefixed with the dataset name: `DatasetName.fieldname`. This prefix requirement is a key difference from regular `stats` queries. Without the prefix, `tstats` will not recognize the field.

---

# Domain 10 Using the Common Information Model (CIM)

## What is CIM?

The Common Information Model (CIM) is a Splunk Add-on that provides a set of standardized field names and data models for normalizing data from different sourcetypes and vendors. Its goal is to make data from a Windows firewall, a Palo Alto firewall, and a Cisco ASA all searchable using the same field names so analysts do not need to know vendor-specific field names.

What the CIM add-on includes:

- Pre-configured data models — standardized hierarchical schemas for common data categories
- Fields and event category tags — the normalized field names and required tags that tie data to each model

The CIM does not include custom visualizations or automatic data model acceleration. Acceleration is off by default and must be explicitly enabled.

What the CIM is:

- A methodology for normalizing data — it provides a standardized schema across sources
- A tool that can correlate data from different sources — normalized field names allow joining and comparing events from disparate origins
- A framework used by the Knowledge Manager to create consistent knowledge objects

The CIM is distributed as an app, but describing it only as "an app that can coexist with other apps" understates its nature — it is a broader methodology and framework, not merely a standalone app.

---

## Installing CIM

Download and install the Splunk Common Information Model Add-on from Splunkbase: https://splunkbase.splunk.com/app/1621

After installation, install the vendor-specific technology add-on for each data source you want to normalize (e.g., Splunk Add-on for Microsoft Windows, Splunk Add-on for Palo Alto Networks).

---

## Key CIM Data Models

|Data Model|Use Case|
|---|---|
|Authentication|Login events, failed/successful auth|
|Network Traffic|Firewall, flow logs|
|Network Sessions|VPN, DHCP|
|Intrusion Detection|IDS/IPS alerts|
|Malware|AV/EDR detections|
|Endpoint|Process, file, registry events|
|Web|Web proxy, access logs|
|Email|Mail server logs|
|DNS|DNS query/response logs|
|Alerts|Generic alert data|
|Change|Configuration changes|
|Vulnerabilities|Vulnerability scanner results|
|Databases|Database query/connection/login events|

CIM data models included in the add-on include Alerts, Email, and Databases. "User Permissions" is not a standalone CIM data model — user-related data falls under the Authentication model. This is directly tested.

---

## CIM Field Naming Standards

CIM defines standard field names. When you normalize data to CIM, you map vendor-specific fields to these standard names using field aliases and tags.

Authentication model fields:

|CIM Field|Description|
|---|---|
|`src`|Source IP|
|`dest`|Destination IP|
|`user`|Username|
|`action`|`success`, `failure`, `allowed`, `blocked`|
|`app`|Application name|
|`signature`|Event signature or name|

Network Traffic model fields:

|CIM Field|Description|
|---|---|
|`src_ip`|Source IP|
|`dest_ip`|Destination IP|
|`src_port`|Source port|
|`dest_port`|Destination port|
|`transport`|Protocol (TCP, UDP)|
|`bytes_in` / `bytes_out`|Traffic volume|
|`action`|allow/block|

---

## Normalizing Data to CIM

To normalize a sourcetype to CIM:

1. Install the CIM Add-on
2. Install the vendor-specific Add-on (e.g., Splunk Add-on for Microsoft Windows)
3. The Add-on applies field aliases and tags that map vendor fields to CIM fields
4. Tag events with the correct CIM tag (e.g., `tag=authentication`)

The knowledge objects the CIM uses to normalize data — in addition to field aliases, event types, and tags — are lookups and field extractions. Macros and workflow actions are not core CIM normalization mechanisms.

---

## CIM Tags

CIM uses tags to identify which data model an event belongs to. Every CIM data model has required tags that must be present on events for them to be recognized by the data model.

Authentication model tags:

```
tag=authentication
```

Network Traffic model tags:

```
tag=network
tag=communicate
```

Malware model tags:

```
tag=malware
tag=attack
```

An event must have the required CIM tags to appear in the corresponding data model's dataset. This is how the data model knows which events to include without scanning all indexes.

---

## Searching Normalized CIM Data

```splunk
tag=authentication action=failure
| stats count by user, src
```

This search works across any sourcetype that has been properly normalized to the CIM Authentication model — Windows security logs, Linux PAM logs, Cisco ASA VPN logs, etc. — all use the same `user` and `src` field names after normalization.

```splunk
tag=network tag=communicate dest_port=443
| stats sum(bytes_out) AS total_out by src_ip
```

```splunk
| datamodel Authentication Successful_Authentication search
| stats count by Authentication.user
| sort -count
| head 20
```

Once data is CIM-normalized, you can use Pivot against CIM data models or use `tstats` for fast queries without knowing the original sourcetype-specific field names. This is the main value proposition of CIM — write once, search everywhere.

---

# Knowledge Objects Summary

Knowledge objects are configurations that enrich or transform data at search time. They are stored in Splunk and shared across users based on permissions.

| Knowledge Object | Purpose                                                                                                           |
| ---------------- | ----------------------------------------------------------------------------------------------------------------- |
| Field Extraction | Pull structured fields from raw event text; saved to props.conf and transforms.conf; persists across searches     |
| Field Alias      | Give an existing field an alternate name; both original and alias remain accessible; used in lookup definitions   |
| Calculated Field | Derive a new field using an eval expression; saved as a knowledge object applied automatically at search time     |
| Tag              | Label a specific field-value pair with a meaningful name; case-sensitive; based on field/value pairs              |
| Event Type       | Categorize events that match a search; no time range required; can be tagged; priority controls color             |
| Macro            | Reusable SPL snippet with optional arguments; called with backtick syntax; arguments resolved at execution time   |
| Lookup           | Enrich events with data from external tables (CSV, KV Store); applied after field extractions and aliases         |
| Workflow Action  | Add custom links or searches to the event actions menu; GET opens URL, POST submits data, Search runs SPL         |
| Data Model       | Hierarchical schema built on searches; two parts of root event dataset are constraints and fields; used for Pivot |
| Report           | Saved search result                                                                                               |
| Alert            | Saved search that triggers an action on a schedule or in real-time                                                |
| Dashboard        | Collection of panels using searches or reports                                                                    |


![[Digram.png]]

---

# Lookups

## What is a Lookup?

A lookup enriches events with additional data from an external file (CSV) or a KV Store. At search time, Splunk matches a field in the event against a column in the lookup table and returns the corresponding row values as new fields on the event.

---

## CSV Lookup

Creating a CSV Lookup:

1. Create your CSV file with headers
2. Settings → Lookups → Lookup Table Files → Add New
3. Upload the file and give it a name
4. Settings → Lookups → Lookup Definitions → Add New
5. Define the lookup: name, file, input field(s), output field(s)

Example CSV (`ip_owners.csv`):

```
ip,owner,department,risk_level
10.0.0.1,Alice,IT,low
10.0.0.2,Bob,Finance,medium
192.168.1.50,Charlie,HR,high
```

Lookup definition:

```
Name: ip_owners
File: ip_owners.csv
Input Field: ip
Output Fields: owner, department, risk_level
```

Using the lookup in a search:

```splunk
index=web_logs
| lookup ip_owners ip AS src_ip OUTPUT owner, department, risk_level
| table _time, src_ip, uri, status, owner, department, risk_level
```

This adds `owner`, `department`, and `risk_level` to each event based on `src_ip` matching the `ip` column in the CSV.

---

## Automatic Lookup

An automatic lookup applies a lookup to every event of a specific sourcetype automatically — you do not need to call `lookup` manually in every search.

Creating an Automatic Lookup: Settings → Lookups → Automatic Lookups → New

After setting up an automatic lookup, the enriched fields appear automatically in every search against that sourcetype.

---

## KV Store Lookup

KV Store is a MongoDB-based key-value store built into Splunk. Used for dynamic lookups that change frequently — watchlists, asset lists, threat intelligence feeds that update regularly.

```splunk
| inputlookup asset_list
| where risk_score > 80
```

```splunk
| outputlookup asset_list
```

---

## `inputlookup` and `outputlookup`

```splunk
| inputlookup ip_owners.csv
```

Reads the entire CSV as a dataset — useful for browsing lookup contents or manipulating them before writing back.

```splunk
index=web_logs
| stats count by src_ip
| outputlookup scan_results.csv
```

Writes search results to a lookup file. Useful for creating dynamic lookup tables from search results.

---

# Working with Time

## Time Modifiers

Time modifiers restrict the search time range. They can be set in the time picker or inline in the search string.

```splunk
index=web_logs earliest=-24h latest=now
```

```splunk
index=web_logs earliest=-7d@d latest=@d
```

This searches from the start of the day 7 days ago through the start of today (midnight to midnight, not including today's events).

Time modifier syntax:

|Modifier|Meaning|
|---|---|
|`now`|Current time|
|`-1h`|1 hour ago|
|`-7d`|7 days ago|
|`@h`|Snap to start of current hour|
|`@d`|Snap to start of today (midnight)|
|`@w`|Snap to start of current week|
|`@mon`|Snap to start of current month|
|`-1d@d`|Start of yesterday (midnight yesterday)|
|`@d+8h`|Today at 08:00|

---

## Time Functions in `eval`

```splunk
index=web_logs
| eval event_date = strftime(_time, "%Y-%m-%d")
| eval event_hour = strftime(_time, "%H")
```

```splunk
index=web_logs
| eval age_seconds = now() - _time
| eval age_hours = round(age_seconds / 3600, 1)
| eval age_display = tostring(age_seconds, "duration")
```

Common strftime format codes:

|Code|Meaning|
|---|---|
|`%Y`|4-digit year|
|`%m`|2-digit month (01-12)|
|`%d`|2-digit day of month (01-31)|
|`%H`|Hour in 24-hour format (00-23)|
|`%M`|Minute (00-59)|
|`%S`|Second (00-59)|
|`%A`|Full day name (Monday)|
|`%b`|Abbreviated month name (Jan)|
|`%s`|Unix epoch timestamp|

---

## The `bucket` Command (Time Bucketing)

`bucket` groups continuous values — especially time — into discrete buckets. Equivalent to `bin`. Useful when you want to group events by time intervals without using `timechart`.

```splunk
index=web_logs
| bucket _time span=1h
| stats count by _time, status
```

This creates hourly time buckets and counts events by status within each hour. Unlike `timechart`, the result is a table, not a chart.

```splunk
index=web_logs
| bucket response_bytes span=1000
| stats count by response_bytes
```

This groups events into 1000-byte buckets by response size — useful for building a distribution histogram.

---

# Statistical Processing — Advanced

## `eventstats` Command

Like `stats` but adds the result as a new field to each original event rather than replacing the results. The original events are preserved with the computed statistics added.

```splunk
index=web_logs
| eventstats avg(response_bytes) AS avg_bytes by host
| eval above_avg = if(response_bytes > avg_bytes, "yes", "no")
| table _time, host, uri, response_bytes, avg_bytes, above_avg
```

Each individual event keeps its own `response_bytes` value and gains a new `avg_bytes` field showing the average for its host. The subsequent `eval` can then compare the individual event's value against the group average.

---

## `streamstats` Command

Like `eventstats` but calculates statistics in a running or sliding window as events are processed in time order. Results change as more events are processed.

```splunk
index=web_logs
| sort _time
| streamstats count AS event_number by src_ip
```

This assigns a sequential event number per `src_ip` — useful for identifying the Nth occurrence of an event for each user or IP.

```splunk
index=web_logs
| sort _time
| streamstats window=5 avg(response_bytes) AS rolling_avg
```

Calculates a 5-event rolling average of `response_bytes`.

---

## `appendcols` Command

Appends the output of a subsearch as new columns to the existing results by row position, not by field join.

```splunk
index=web_logs
| stats count AS total_requests by host
| appendcols
    [search index=web_logs status>=400
     | stats count AS error_requests by host]
```

---

# Comparing Values — `eval` Operators

Comparison operators in eval:

|Operator|Meaning|
|---|---|
|`==`|Equal|
|`!=`|Not equal|
|`<` / `>`|Less than / Greater than|
|`<=` / `>=`|Less or equal / Greater or equal|
|`AND` / `OR` / `NOT`|Boolean operators|
|`.`|String concatenation|
|`+` `-` `*` `/` `%`|Arithmetic operators|

The `?=` operator does not exist in Splunk — this is the exam-tested invalid operator.

---

# Result Modification Commands

## `head` and `tail`

```splunk
index=web_logs | head 10
index=web_logs | tail 10
```

`head` returns the first N results from the current result set. `tail` returns the last N. Default is 10 if no number is specified.

---

## `reverse`

```splunk
index=web_logs | reverse
```

Reverses the current result set order.

---

## `highlight`

Highlights specified terms in the events view.

```splunk
index=web_logs
| highlight src_ip, "404", "500"
```

---

## `untable`

Converts a table with multiple columns into rows — the inverse of `xyseries`.

---

## `xyseries`

Converts rows into a table format suitable for charting — inverse of `untable`.

```splunk
index=web_logs
| stats count by _time, status
| xyseries _time status count
```

---

# SPL Quick Reference

## Search Pipeline Structure

```
index=<n> [filters] [field=value ...]
| command1 [options]
| command2 [options]
| ...
```

## Most Used Commands

|Command|Purpose|
|---|---|
|`search`|Filter events by keyword or field value; implied at start of search; also used mid-pipeline|
|`eval`|Create or modify fields; supports math, string, conditional, and conversion functions|
|`stats`|Aggregate statistics into a table; faster than transaction; used for counts, sums, averages|
|`chart`|Aggregate into a chart table over a field (x-axis); supports `over` and `by` clauses|
|`timechart`|Aggregate over time; `_time` is always the x-axis; only one field after `by`|
|`table`|Select and order columns to display|
|`fields`|Keep (`+`) or remove (`-`) fields from results|
|`where`|Filter using eval expressions; used after stats for computed field filtering|
|`dedup`|Remove duplicate events by field combination|
|`sort`|Sort results ascending (`+`) or descending (`-`)|
|`rename`|Rename fields|
|`rex`|Inline regex extraction using named capture groups; does not persist|
|`lookup`|Enrich events with data from lookup tables|
|`transaction`|Group related events into single super-events; adds duration and eventcount|
|`fillnull`|Replace null field values (default 0 if no value argument specified)|
|`top` / `rare`|Most or least frequent field values; auto-includes count and percent|
|`head` / `tail`|First or last N results|
|`bucket` / `bin`|Group continuous values into discrete buckets|
|`eventstats`|Add group statistics to individual events without collapsing them|
|`streamstats`|Running statistics that update as each event is processed in order|
|`tstats`|Fast stats on accelerated data models using tsidx summaries|
|`inputlookup`|Read all records from a lookup file into results|
|`outputlookup`|Write current results to a lookup file|
|`append`|Append subsearch results as additional rows|
|`join`|Join subsearch results on a shared field|

---

# Exam-Focused Concept Clarifications

## The search command

The `search` command behaves exactly like search strings before the first pipe. It supports wildcards, is case-insensitive by default, and can be used anywhere in the pipeline. The search command is not restricted to the beginning of the search — this is commonly misunderstood.

## eval command

Can create or replace an existing field. Cannot remove fields (use `fields -` for that). Cannot group transactions (use `transaction` for that). Cannot save SPL commands (use macros for that). The eval command performs calculations, formats values, converts types, and applies conditional logic.

## Macros — when can a pipe follow?

A pipe may always follow a macro. Ownership and sharing settings affect whether you can access the macro — not the syntax of chaining it with a pipe once you have access.

## field alias vs calculated field vs field extraction

- Field extraction — parses a new field from raw event text using regex or delimiter; both the original raw text and the new field are available; persists as a knowledge object
- Field alias — gives an existing already-extracted field an alternate name; both names remain accessible; does not replace the original
- Calculated field — derives a new field using an eval expression; saved as a knowledge object; applied automatically at search time

## transaction maxspan

Sets the maximum total time between the earliest and latest events in a transaction. It does not limit the time between consecutive events (that is `maxpause`), the length of a single event's text, or the total number of events (that is `maxevents`).

## fillnull default

When no value argument is specified, `fillnull` replaces nulls with 0.

## chart equivalency

`| chart count by vendor_action, user` produces identical results to `| chart count over vendor_action by user`. A comma-separated by clause is equivalent to using over and by separately, provided fields are in the correct order.

## datamodel command syntax

`| datamodel <ModelName> <DatasetName> search` — the first argument is the data model, the second is the dataset within that model.

## Event type priority

When multiple event types with different colors are assigned to the same event, priority (configured in `eventtypes.conf`) determines which color is displayed. Lower priority numbers win — priority 1 beats priority 10.

## CIM acceleration default

Off by default. Must be explicitly enabled by an admin with the `accelerate_datamodel` capability.

## Knowledge object application order

Field Extractions → Field Aliases → Lookups

This order cannot be reversed. Aliases require extractions to exist first. Lookups require aliases to be resolved first.

## Who uses pivots?

Pivots are most commonly used by end users — business analysts who need to explore data without writing SPL. Architects design systems, Knowledge Managers maintain knowledge objects, and Administrators configure Splunk. The hands-on day-to-day Pivot use is by end users.

## sort first, then eval

To sort numerically and then display as a string, always sort on the numeric field first, then convert to string with eval. Sorting after string conversion produces lexicographic order.

## tag search behavior

`tag=Priv*` matches tags beginning with "Priv" including "Privileged". `tag=Priv` matches only the exact tag "Priv". Tags are case-sensitive — `tag=Privileged` is distinct from `tag=privileged`.

## Patterns tab

The Patterns tab shows event patterns in the results of a specific search — not the Statistics or Visualization tabs.

## Default search result order

By default, search results are returned in reverse chronological order (most recent first), not chronological order and not alphabetical order.

---

# Exam Tips

High-Priority Topics:

- `eval` functions — know the syntax: `if`, `case`, `round`, `strftime`, `match`, `coalesce`, `mvindex`, `tostring` with valid format arguments (`hex`, `commas`, `duration` — not `decimal`)
- `stats` vs `chart` vs `timechart` — same function set; `stats` makes tables, `chart` makes X/Y charts, `timechart` always uses `_time` as X-axis
- `transaction` vs `stats` — `stats` is faster; `transaction` adds `duration` and `eventcount`; 1000-event limit; use `transaction` for start/end grouping
- Field extractions: `rex` named capture group syntax `(?P<name>pattern)`; FX persists to `props.conf`/`transforms.conf`; after manual regex edit, FX UI can no longer edit the extraction
- Macro syntax: backtick calls `` `macroname` ``; argument syntax `$argname$` in definitions; argument count in name e.g. `macroname(2)`; pipe may always follow a macro
- Workflow action types: GET requires name, URI, label; GET opens URLs; POST sends POST arguments; Search uses field values for secondary search; all run with user's own permissions
- CIM tags: `tag=authentication`, `tag=network`, etc.; CIM includes Alerts, Email, Databases; not "User Permissions"
- Lookup: difference between `lookup` (inline), `inputlookup` (read file), `outputlookup` (write file), automatic lookup (applied without calling it)
- Time modifiers: `earliest`, `latest`, snap syntax `@d`, `@h`; `span` argument controls bucket size in `timechart`
- Data models: two parts of root event dataset are constraints and fields; root events can be accelerated; accelerated models cannot be edited; private models cannot be accelerated; acceleration defaults to off
- `tstats` requires field prefix with dataset name (e.g., `Authentication.user`)
- `fillnull` default value is 0
- `timechart` x-axis is always `_time`; only 1 field after `by`; `span` controls time bucketing
- Knowledge object order: Extractions → Aliases → Lookups
- FX auto-identifies sourcetype from Event Actions → Extract Fields
- Shared report returns no results: extraction is private, or user lacks index access
- `maxspan` = max time between earliest and latest event in a transaction; `maxpause` = max gap between consecutive events
- Export formats: XML and JSON only
- Verbose mode returns all extracted fields; Fast mode returns only default fields; Patterns tab shows event patterns
- CIM acceleration: off by default; accelerated models cannot be edited; private models cannot be accelerated
- Tags are case-sensitive; based on field/value pairs; `tag=Priv*` for wildcard matching
- Event types can be tagged; categorize events based on a search; do not require a time range; priority determines color when multiple apply
- `tag::host=alert` limits a tag search to a specific field
- `sort` first numerically, then `eval` to convert to string (to preserve numeric sort order)
- `?=` is not a valid comparison operator; `"decimal"` is not a valid tostring format
- `where` evaluates expressions; `search` treats values as keywords — use `where` after `stats` for expression filtering
- A space in a search string is an implied AND
- By default results are in reverse chronological order, not chronological or alphabetical

Common Mistakes to Avoid:

- Using `search` instead of `where` after `stats` — `search` does not evaluate expressions like `count > 10` as reliably as `where`
- Forgetting backticks around macro names — single or double quotes do not expand macros
- Confusing `fields +` (keep only listed fields) with `fields -` (remove listed fields)
- Using `transaction` on large datasets — prefer `stats` when aggregate values are enough; `transaction` is slower and limited to 1000 events per group
- Subsearch results are capped at 10,000 events and 60 second timeout
- `fillnull` without a field name affects ALL fields
- `chart` requires an `over` or `by` clause; `timechart` uses `_time` automatically
- Confusing `maxspan` (total transaction duration) with `maxpause` (gap between consecutive events)
- Thinking CIM acceleration is on by default — it is off
- Thinking field aliases replace the original field name — they do not; both the original and alias remain accessible
- Confusing "calculated field" (eval expression knowledge object) with "field extraction" (regex parsing from raw text)
- Thinking `maxspan` is added as a result field after `transaction` — it is not; only `duration` and `eventcount` are added
- Thinking `tag=Priv` matches "Privileged" — it does not without a wildcard; use `tag=Priv*`
- Thinking export formats include HTML — they do not; only XML and JSON
- Thinking Verbose mode is the default — Smart mode is the default
- Thinking Knowledge Managers are the primary Pivot users — end users are