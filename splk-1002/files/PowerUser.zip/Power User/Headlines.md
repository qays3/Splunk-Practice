



## Certification Overview

- **Exam:** Splunk Core Certified Power User
- **Prerequisite Exam:** None (Splunk Core Certified User is recommended but not required)
- **Delivery:** Pearson VUE  in-person or online proctored
- **Skills Validated:** SPL searching and reporting, knowledge objects, field aliases, calculated fields, macros, workflow actions, data models, CIM normalization

---

## Official Splunk Resources

|Resource|Link|
|---|---|
|Certification Track Page|https://www.splunk.com/en_us/training/certification-track/splunk-core-certified-power-user.html|
|Exam Blueprint (PDF)|https://www.splunk.com/en_us/pdfs/training/splunk-test-blueprint-power-user.pdf|
|Certification Study Guide|https://www.splunk.com/en_us/resources/splunk-certification-exam-study-guide.html|
|Exam Registration Guide|https://www.splunk.com/en_us/resources/splunk-core-certified-power-user.html|
|Splunk Documentation|https://docs.splunk.com|
|Splexicon Glossary|https://docs.splunk.com/Splexicon|
|Splunk Training Portal|https://www.splunk.com/en_us/training/course-catalog.html|
|Splunk Learning Paths|https://www.splunk.com/en_us/training/learning-paths.html|
|Splunk Fundamentals Overview|https://www.splunk.com/en_us/training/splunk-fundamentals.html|
|Splunk How-To YouTube Channel|https://www.youtube.com/@splunk_ml/videos|

---

## Exam Blueprint  Required Topics

From the official Splunk exam blueprint, the following courses and topics are covered:

1. Working with Time
2. Statistical Processing
3. Comparing Values
4. Result Modification
5. Correlation Analysis
6. Creating Knowledge Objects
7. Creating Field Extractions
8. Data Models

---

## Official Free Training Courses (Splunk Training Portal)

Complete these in order via the Core Certified Power User Learning Path:

- Working with Time
- Statistical Processing
- Comparing Values
- Result Modification
- Correlation Analysis
- Creating Knowledge Objects
- Creating Field Extractions
- Data Models
- Splunk Fundamentals 1 (legacy, still available free)
- Splunk Fundamentals 2 (legacy, still available  free)

Access all at: https://www.splunk.com/en_us/training/course-catalog.html

---

## Udemy Courses

|Course|Link|
|---|---|
|The Complete Splunk Core Certified Power User Course (RylKim Solutions)  4.7+ rating|https://www.udemy.com/course/the-complete-splunk-core-certified-power-user-course/|
|Splunk Core Certified Power User Practice Exam  New 2025|https://www.udemy.com/course/splunk-core-certified-power-user-practice-cert-exam-course/|
|Splunk Core Certified Power User Exam 2024 (6 Practice Tests)|https://www.udemy.com/course/splunk-core-certified-power-user-exam-2024/|

---

## Practice Exams

|Platform|Link|
|---|---|
|SkillCertPro  645 Practice Questions (2026)|https://skillcertpro.com/product/splunk-core-certified-power-user-exam-questions/|
|Udemy Practice Tests (multiple vendors)|https://www.udemy.com/courses/search/?q=splunk+core+certified+power+user+practice|

---

## Books

|Title|Link|
|---|---|
|Splunk Certified Study Guide  Mehta (Covers User, Power User, Enterprise Admin)|https://www.amazon.com/Splunk-Certified-Study-Guide-Certifications/dp/1484266684|

---

## Community & Support

|Resource|Link|
|---|---|
|Splunk Community  Training & Certification Forum|https://community.splunk.com/t5/Training-Certification/bd-p/training-certification|
|Splunk4Rookies Virtual Workshops|https://discover.splunk.com/EMEA_Virtual_Workshops.html|

---

## Exam Registration Steps

1. Create or log in to your Splunk account at splunk.com
2. Connect your Splunk account to Pearson VUE
3. Submit accurate contact information to Pearson VUE
4. Wait up to 2 business days for Authorization to Test email
5. Create a Pearson VUE account
6. Schedule your exam appointment

---

## Recommended Study Path

1. Read the exam blueprint PDF thoroughly
2. Complete all free courses on the Splunk training portal in the listed order
3. Set up a local Splunk instance and practice with real datasets
4. Review Splunk Docs and Splexicon for any gaps
5. Take at least 2 full practice exams (target 85%+ before booking)
6. Register and sit the exam via Pearson VUE

---

## What the Exam Tests

- SPL commands: search, stats, eval, timechart, chart, rex, and others
- Field extractions using regex and delimiters
- Field aliases and calculated fields
- Tags and event types
- Macros with and without arguments
- Workflow actions (GET, POST, search)
- Data models and pivot
- CIM (Common Information Model) normalization
- Lookups (CSV and KV Store)
- Time modifiers and time functions
- Subsearches
- Report acceleration and summary indexing concepts